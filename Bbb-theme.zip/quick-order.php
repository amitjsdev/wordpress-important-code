<?php
/**
 * Template name: quick-order
 */

  $cookie_name = "quickOrder";
  $cookie_id =$_COOKIE[$cookie_name];
	if($cookie_id != "") {
			 $product_session_id =$cookie_id;
		
		}
global $wpdb;		
if(isset($_GET['remove_id'])){
	$table_delete = $wpdb->prefix . 'quickProducts';
	$remove_id = $_GET['remove_id'];
	$qryy_delete=$wpdb->query("DELETE FROM $table_delete where id='$remove_id'"); 
	if($qryy_delete){
		echo "sucess";
	}
}		
	
if(isset($_POST['quickAction'])){
		$len = 10;
		function randStrGen($len){
			$result = "";
			$chars = "abcdefghijklmnopqrstuvwxyz0123456789$11";
			$charArray = str_split($chars);
			for($i = 0; $i < $len; $i++){
				$randItem = array_rand($charArray);
				$result .= "".$charArray[$randItem];
			}
				return $result;
		}
		if($product_session_id == ""){
			 $product_session_id =  randStrGen($len);
		}
global $wpdb;
  $table_name = $wpdb->prefix . 'quickProducts';
  $in = $wpdb->query("INSERT INTO `$table_name`(`boeketproduct`,`color`,`checkboxBooket`,`numberCard`,`cardWords`,`prefer`, `product_session_id`) VALUES ('".$_POST['boeketproduct']."', '".$_POST['color']."', '".$_POST['checkboxBooket']."', '".$_POST['numberCard']."', '".$_POST['cardWords']."', '".$_POST['prefer']."', '$product_session_id')");
  if($in){
	  
	  $cookie_name = "quickOrder";
	 setcookie($cookie_name, $product_session_id, time() + (86400 * 365), "/");
	 
	 echo ("<script>location.href='/static/wp-bbb/snel-bestellen/'</script>");
	 
	/*   if($_POST['boeketproduct'] != ''){

		$boeketproduct = 'Bouquet ('.$_POST['boeketproduct'].')<br>';
	}
	
	if($_POST['color'] != ''){
		
		$color = 'Color ('.$_POST['color'].')<br>';
	}
	
	if($_POST['checkboxBooket'] != ''){
		
		$checkboxBooket = 'Vase  ('.$_POST['checkboxBooket'].')<br>';
	}
	
	if($_POST['numberCard'] != ''){
		
		$numberCard = 'Numbers ('.$_POST['numberCard'].')<br>';
	}
	
   if($_POST['cardWords'] != ''){
		
		$cardWords = 'Card Text('.$_POST['cardWords'].')<br>'; 
	}
    if($_POST['prefer'] != ''){
		
		$prefer = 'prefer ('.$_POST['prefer'].')<br>'; 
	}
		$top_txt ='Quick Order<br><br>';
		//$middle_mesg ='Camper For Rental :<br><br>';
		$to = "amit4510201@gmail.com";
		$subject = "Quick Order ";
		$txt = $top_txt;
		//$txt .= $middle_mesg;
		$txt .= $boeketproduct;
		$txt .= $color;
		$txt .= $checkboxBooket;
		$txt .= $numberCard;
		$txt .= $cardWords;
		$txt .= $prefer;
		$txt .= "<br><br>Thanks";
		$headers = "From: bansalsuhasi@gmail.com" . "\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		mail($to,$subject,$txt,$headers);
	 echo $sucess = "Successfully Sended "; */
  }
}
 global $wpdb;
if(isset($_POST['deliveryButton'])){
	if(isset($_POST['orderPlace'])){
				$currentDate = date("M,d,Y h:i:s A"); 
				if($_POST['name_delivery']){
					$name = $_POST['name_delivery'];
				}else{
					$name = $_POST['name_sender'];
				}
				$totalPrice = $_POST['totalPrice'];
				$status = "Processing"; 
				$orderPlace = $wpdb->prefix . 'orderPlace';
				$orders = $wpdb->query("INSERT INTO `$orderPlace`(`name`, `currentDate`,`totalPrice`,`status`) VALUES ('".$name."','".$currentDate."', '".$totalPrice."', '".$status."')");
				$orderId = $wpdb->insert_id;
				if($orderId){
					$orderboeket = $_POST['orderboeket'];
					$orderPrice = $_POST['orderPrice'];
					$orderCardWords = $_POST['orderCardWords'];
					$orderPrefer = $_POST['orderPrefer'];
					$orderProduct = $wpdb->prefix . 'orderProduct';
						foreach ($orderboeket as $key=>$val) {
							$orders = $wpdb->query("INSERT INTO `$orderProduct`(`orderboeket`, `orderPrice`, `orderCardWords`, `orderPrefer`,`orderId`) VALUES ('".$orderboeket[$key]."','".$orderPrice[$key]."', '".$orderCardWords[$key]."', '".$orderPrefer[$key]."','".$orderId."')");
						}
					if(isset($_POST['deliverAddress'])){
						$table_name2 = $wpdb->prefix . 'quickdelivery';
						$indelivery = $wpdb->query("INSERT INTO `$table_name2`(`company_delivery`, `salutation_delivery`, `name_delivery`, `country_delivery`,`street_delivery`,`plaats_delivery`,`telefoonnummer_delivery`,`email_delivery`,`date_delivery`,`orderId`) VALUES ('".$_POST['company_delivery']."','".$_POST['salutation_delivery']."', '".$_POST['name_delivery']."', '".$_POST['country_delivery']."', '".$_POST['street_delivery']."', '".$_POST['plaats_delivery']."', '".$_POST['telefoonnummer_delivery']."', '".$_POST['email_delivery']."','".$_POST['date_delivery']."','$orderId')");
					}
				
					if(isset($_POST['senderAddress'])){
						$table_name3 = $wpdb->prefix . 'quickSender';
						$inquickSender = $wpdb->query("INSERT INTO `$table_name3`(`sender_company`, `sender_salutation`, `name_sender`, `country_sender`, `postcode_sender`,`plaats_sender`,`telefoonnummer_sender`,`email_sender`,`newsCheckbox`,`coments_sender`,`orderId`) VALUES ('".$_POST['sender_company']."','".$_POST['sender_salutation']."', '".$_POST['name_sender']."', '".$_POST['country_sender']."', '".$_POST['postcode_sender']."', '".$_POST['plaats_sender']."', '".$_POST['telefoonnummer_sender']."', '".$_POST['email_sender']."', '".$_POST['newsCheckbox']."', '".$_POST['coments_sender']."','$orderId')");
					}
					
					/*email section start here */
					
		$table_name = $wpdb->prefix . 'orderPlace';
		$result=$wpdb->get_results( "SELECT * FROM $table_name where id='$orderId'");
		$result_count = $wpdb->num_rows;

			$to = 'k.chabra007@gmail.com';
			$subject  = "Quick Order";
			$tabel = '<table cellspacing=\"4\" cellpadding=\"4\" border=\"1\" align=\"center\">
								<thead>
								<tr>
									<th scope="col"  class="manage-column column-role">S No.</th>
									<th scope="col"  class="manage-column column-name">Orderboeket</th>
									<th scope="col"  class="manage-column column-name">OrderPrice</th>
									<th scope="col"  class="manage-column column-name">OrderCardWords</th>
									<th scope="col"  class="manage-column column-name">orderPrefer</th>
								</tr>
							</thead>
							<tbody id="the-list" data-wp-lists="list:user">';
		 

		 $a=1;
		 global $wpdb;
		  $table_orderProduct= $wpdb->prefix . 'orderProduct';
			$result_product=$wpdb->get_results( "SELECT * FROM $table_orderProduct where orderId='$orderId'");
			$result_orderProduct = $wpdb->num_rows;
			if($result_orderProduct != 0){
				foreach ( $result_product as $result_val ){
				$tabel.='<tr>
							<th>'. $a .'"</th>
							<td>'. $result_val->orderboeket .'</td>
							<td>'. $result_val->orderPrice  .'</td>
							<td>'. $result_val->orderCardWords .'</td>
							<td>'. $result_val->orderPrefer .'</td>
						</tr>';	

		$a++;
					}
				}						
			$tabel.='</tbody>
			</table>';
			
			$tabel .= '<br><table cellspacing=\"4\" cellpadding=\"4\" border=\"1\" align=\"center\">
								<thead>
								<tr>
									<th scope="col"  class="manage-column column-role">S No.</th>
									<th scope="col"  class="manage-column column-role">Total Amount.</th>
								</tr>
							</thead>
							<tbody id="the-list" data-wp-lists="list:user">';
						$tabel.='<tr>
									<td>1</td>
									<td>'. $totalPrice .'</td>
								</tr>';	
										
					$tabel.='</tbody>
					</table>';


		/*end product  email*/
		/*delivery email start*/	
		if($indelivery){
		 $table_quickdelivery = $wpdb->prefix . 'quickdelivery';
		$result_quickdelivery=$wpdb->get_results( "SELECT * FROM $table_quickdelivery where orderId='$orderId'");
		$quickdelivery_count = $wpdb->num_rows;

			$tabel.='<br><br><div class="order_data_column firstDiv">
						<h3>
							Delivery Address
						</h3>
						<p><strong>Bedrijf:</strong>'.$result_quickdelivery[0]->company_delivery.'</p>
						<p><strong>Aanhef:</strong>'.$result_quickdelivery[0]->salutation_delivery .'</p>
						<p><strong>Naam::</strong>'. $result_quickdelivery[0]->name_delivery .'</p>
						<p><strong>Country::</strong>'.$result_quickdelivery[0]->country_delivery .'</p>
						<p><strong>Straat en huisnummer:</strong>'. $result_quickdelivery[0]->street_delivery .'</p>
						<p><strong>Plaats:</strong>'. $result_quickdelivery[0]->plaats_delivery .'</p>
						<p><strong>Telefoonnummer:</strong>'. $result_quickdelivery[0]->telefoonnummer_delivery .'</p>		
						<p><strong>E-mail:</strong>'.$result_quickdelivery[0]->email_delivery.'</p>		
						<p><strong>Bezorgdatum:</strong>'. $result_quickdelivery[0]->date_delivery.'</p>		
					</div>';
		}

		if($inquickSender){
		$table_Sender = $wpdb->prefix . 'quickSender';
		$result_Sender=$wpdb->get_results( "SELECT * FROM $table_Sender where orderId='$orderId'");
		$Sender_quickdelivery = $wpdb->num_rows;

			$tabel.='<br><br><div class="order_data_column firstDiv">
						<h3>
							Sender Address
						</h3>
						<p><strong>Bedrijf:</strong>'.$result_Sender[0]->sender_company.'</p>
						<p><strong>Aanhef:</strong>'.$result_Sender[0]->sender_salutation .'</p>
						<p><strong>Naam::</strong>'. $result_Sender[0]->name_sender .'</p>
						<p><strong>Country::</strong>'.$result_Sender[0]->country_sender .'</p>
						<p><strong>Straat en huisnummer:</strong>'. $result_Sender[0]->postcode_sender .'</p>
						<p><strong>Plaats:</strong>'. $result_Sender[0]->plaats_sender .'</p>
						<p><strong>Telefoonnummer:</strong>'. $result_Sender[0]->telefoonnummer_sender .'</p>		
						<p><strong>E-mail:</strong>'.$result_Sender[0]->email_sender.'</p>		
						<p><strong>Bezorgdatum:</strong>'. $result_Sender[0]->coments_sender.'</p>		
					</div>';
		}
		/*delivery email end*/			
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		$headers .= 'From: My Site Name <me@mysite.com>' . "\r\n";

		mail($to, $subject, $tabel, $headers);
		/*

				 */
					/*email section end here */
					if (isset($_COOKIE['quickOrder'])) {
						unset($_COOKIE['quickOrder']);
						setcookie('quickOrder', '', time() - 3600, '/'); // empty value and old timestamp
					}
						echo ("<script>location.href='/static/wp-bbb/snel-bestellen/?successorder=sucess'</script>");
				
			}
		}
}

 $a=1;
 
  $table_name = $wpdb->prefix . 'quickProducts';
	$result=$wpdb->get_results( "SELECT * FROM $table_name where product_session_id ='$product_session_id'");
	$result_count = $wpdb->num_rows;
	
	if($result_count != 0){
		$preferArray=array();
		foreach ( $result as $print ){
			$preferArray[]=$print->prefer;
		}
		$prefer ="Ophalen";
		if(in_array($prefer, $preferArray)){
			$sender = $prefer;
		}

		$deliever = "Levering";
		if (in_array($deliever, $preferArray)){
			$delievery = $deliever;
		}

		if($sender == $prefer AND $delievery == $deliever){
			$deliever_quick = "Levering";
			$prefer_quick ="Ophalen";
			$displaySender = "display:block";
			$displayDilevery = "display:block";
			$required="required";
		}elseif($delievery){
			$deliever_quick = "Levering";
			$prefer_quick ="Ophalen";
			$displaySender = "display:block";
			$displayDilevery = "display:block";
			$required="required";
		}elseif($sender){
			$prefer_quick ="Ophalen";
			$displaySender = "display:block";
			$displayDilevery = "display:none";
			$required="required";
		}	
	}	

get_header(); 
	?>
<style>
.order-checkout p.product.woocommerce.add_to_cart_inline{
	display:none;
	
}
.order-checkout .quantity.block-product-detail{
	display:none;
}
.block-address.dileveryDiv{
    margin-top: 40px;
}
.selectValue{
	display:none;
}
.Vaas{
	display:none;
}
.Aantal{
	display:none;
}
.liever{
	display:none;
}
</style>

<section class="page-title-block" data-aos="fade-in" data-aos-duration="600" data-aos-delay="100">
  <div class="container">
	<h1>Snel bestellen</h1>
  </div>
</section>
 <section class="order-checkout quickorder_page"> 
          <div class="container">
            <div class="row">
              <div class="col-sm-6">
                <div class="checkout-left-block">
				
		 <form action="" class="cart" id="quickAction" method="post" enctype="multipart/form-data">
					<div class="order-form-field">
						<div class="form-fieldset">
							<select id="quickOrder" name="boeketproduct" class="selectpicker custom-select-style" required>
								<option value="" selected disabled>Boeket:</option>
								<option value="Fur bouquet € 17.50">Fur bouquet € 17.50</option>
								<option value="Fur bouquet € 29.95">Fur bouquet € 29.95</option>
								<option value="Fur bouquet € 29.95">Fur bouquet € 29.95</option>
								<option value="Fur bouquet € 29.95">Fur bouquet € 29.95</option>
							</select>
							<span style="color:red;" class="selectValue">This Field is required</span>
						</div>
					</div>
						 <label>Choose Color</label>
						 <br> 
						<div class="custom-checkbox">				
						<label>
						  <input type="radio" name="color" value="Wit" required>
						  <span>Wit</span>
						</label>
						</div>
						 <br>
						<div class="custom-checkbox">
						<label>
						  <input type="radio" name="color" value="Rood" required>
						  <span>Rood</span>
						</label>
						</div>
						 <br>
						<div class="custom-checkbox">
						<label>
						  <input type="radio" name="color" value="Oranje" required>
						  <span>Oranje</span>
						</label>
						</div>
						 <br>
						 <div class="custom-checkbox">
						<label>
						  <input type="radio" name="color" value="Geel" required>
						  <span>Geel</span>
						</label>
						</div>
						 <br>
						<div class="custom-checkbox">
						<label>
						  <input type="radio" name="color" value="Roze" required>
						  <span>Roze</span>
						</label>
						</div>
						 <br> 
						 <div class="custom-checkbox">
						<label>
						  <input type="radio" name="color" value="Kleurencombi" required>
						  <span>Kleurencombi</span>
						</label>
						</div>
						 <br>
					<div class="custom-checkbox">
                    <label>
                      <input type="checkbox" name="checkboxBooket" class="Vaascheckbox" value="YES">
                      <span>Vaas (helder glas)</span>
                    </label>
					<span style="color:red;" class="Vaas">This Field is required</span>
                  </div>
				  <br><br>
				  <div class="order-form-field">
                    <div class="form-fieldset">
                      <select name="numberCard" id="numberCard" class="selectpicker custom-select-style" required>
                        <option value="" selected disabled>Aantal</option>
                        <option value="1">Aantal option 1</option>
                        <option value="2">Aantal option 2</option>
                        <option value="3">Aantal option 3</option>
                        <option value="4">Aantal option 4</option>
                      </select>
					 <span style="color:red;" class="Aantal">This Field is required</span>
                    </div>
                  </div>
				  <div class="field-set onclick">
                    <textarea name="cardWords" class="text-field" id="message" required></textarea>
                    <label for="message">Tekst kaartje:</label>
                    <span class="note-textarea">Maximaal 50 woorden</span>
                  </div>
					<div class="prefer-block">
						<div class="title-order">Wat heeft u liever?</div>
						<div class="custom-radio">
						  <label>
							<input type="radio" value="Ophalen" class="liverRadio" name="prefer" required>
							<span>Ophalen</span>
						  </label>
						</div>
						<div class="custom-radio">
						  <label>
							<input type="radio" value="Levering" name="prefer" class="liverRadio" required/>
							<span>Levering</span>
						  </label>
						</div>
						 <span style="color:red;" class="liever">This Field is required</span>
					</div>
					 <input type="submit" name="quickAction" class="btn-black" value="Toevoegen aan winkelwagen" />
				</form>

			<form  action=""  method="post">
<?php

	if($deliever_quick == "Levering"){
?>			
                  <div class="block-address dileveryDiv" style="<?php echo $displayDilevery;?>">
				  <input type="hidden" value="<?php echo $deliever;?>" name="deliverAddress" >				  
                    <h2>Bezorgadres</h2>
                    <div class="custom-fieldset">
                      <div class="form-fieldset">
                       <select name="company_delivery" class="selectpicker custom-select-style">
                          <option value="" selected disabled>Bedrijf (optioneel)</option>
                          <option value="Boeket option 1">Boeket option 1</option>
                          <option value="Boeket option 2">Boeket option 2</option>
                          <option value="Boeket option 3">Boeket option 3</option>
                          <option value="Boeket option 4">Boeket option 4</option>
                        </select>
                      </div>
                      <div class="field-set onclick">
                        <input name="salutation_delivery" type="text" class="text-field" <?php echo $required;?>/>
                        <label for="salutation_delivery">Aanhef</label>
                      </div>
                      <div class="field-set onclick">
                        <input name="name_delivery" type="text" class="text-field" <?php echo $required;?>/>
                        <label for="name_delivery">Naam:</label>
                      </div>
						<div class="field-set onclick">
							<input name="country_delivery" type="text" class="text-field" <?php echo $required;?>/>
							<label for="country_delivery">Adres:</label>
                      </div>            
                      <div class="field-set onclick">
                        <input name="street_delivery" type="text" class="text-field" <?php echo $required;?>/>
                        <label for="straat">Straat en huisnummer:</label>
                      </div>
                      <div class="field-set onclick">
                        <input name="plaats_delivery" type="text" class="text-field" <?php echo $required;?>/>
                        <label for="Plaats">Plaats:</label>
                      </div>
                      <div class="field-set onclick">
                        <input name="telefoonnummer_delivery" type="text" class="text-field" <?php echo $required;?>/>
                        <label for="telefoonnummer">Telefoonnummer:</label>
                      </div>
                      <div class="field-set onclick">
                        <input name="email_delivery" type="email" class="text-field" <?php echo $required;?>/>
                        <label for="email">E-mail:</label>
                      </div>
                      <div class="field-set onclick">
                        <input name="date_delivery" type="text" class="text-field" <?php echo $required;?>/>
                        <label for="bezorgdatum">Bezorgdatum:</label>
                      </div>
                    </div>
                  </div>
<?php 
	}

if($prefer_quick == "Ophalen"){
?>				  
                  <div class="block-address senderDiv" style="<?php echo $displaySender;?>">
				  <input type="hidden" value="<?php echo $sender;?>" name="senderAddress" >
                    <h2>Afzender</h2>
                    <div class="custom-fieldset">
                      <div class="form-fieldset">
                        <select name="sender_company" class="selectpicker custom-select-style">
                          <option value="" selected disabled>Bedrijf (optioneel)</option>
                          <option value="Boeket option 1">Boeket option 1</option>
                          <option value="Boeket option 2">Boeket option 2</option>
                          <option value="Boeket option 3">Boeket option 3</option>
                          <option value="Boeket option 4">Boeket option 4</option>
                        </select>
                      </div>
                      <div class="field-set onclick">
                        <input name="sender_salutation" type="text" class="text-field" <?php echo $required;?>/>
                        <label for="message">Aanhef</label>
                      </div>
                      <div class="field-set onclick">
                        <input name="name_sender" type="text" class="text-field" <?php echo $required;?>/>
                        <label for="message">Naam:</label>
                      </div>
					<div class="field-set onclick">
							<input name="country_sender" type="text" class="text-field" <?php echo $required;?>/>
							<label for="country_sender">Adres:</label>
                      </div> 
                      <div class="field-set onclick">
                        <input name="postcode_sender" type="text" class="text-field" <?php echo $required;?>/>
                        <label for="message">Postcode:</label>
                      </div>
                      <div class="field-set onclick">
                        <input name="plaats_sender" type="text" class="text-field" <?php echo $required;?>/>
                        <label for="message">Plaats:</label>
                      </div>
                      <div class="field-set onclick">
                        <input name="telefoonnummer_sender" type="text" class="text-field" <?php echo $required;?>/>
                        <label for="message">Telefoonnummer:</label>
                      </div>
                      <div class="field-set onclick">
                        <input name="email_sender" type="email" class="text-field" <?php echo $required;?>/>
                        <label for="message">E-mail:</label>
                      </div>
                      <div class="newsletter-block-form">
                        <h3>Nieuwsbrief:</h3>
                        <div class="custom-checkbox">
                          <label>
                            <input type="checkbox" name="newsCheckbox" value="Yes">
                            <span>Graag blijf ik op de hoogte!</span>
                          </label>
                          <p>(Uw gegevens worden uitsluitend voor onze nieuwsbrief gebruikt.)</p>
                        </div>
                        <div class="field-set onclick">
                          <textarea name="coments_sender" class="text-field" id="message"></textarea>
                          <label for="coments">Eventuele opmerkingen:</label>
                        </div>
                      </div>
                    </div>
                  </div>
				  
<?php
	}
?>				
                </div>
              </div>
              <div class="col-sm-6">
                <div class="checkout-right-block">
				<?php
				$a=1;
				 $cookie_id =$_COOKIE[$cookie_name];
				global $wpdb;
				$table_name5 = $wpdb->prefix . 'quickProducts';
				$result=$wpdb->get_results( "SELECT * FROM $table_name5 where product_session_id ='$cookie_id'");
				$result_count = $wpdb->num_rows;
				?>				
                  <div class="cart-heading">
                    Uw winkelmandje<span class="counter"><?php echo $result_count;?></span>
                  </div>
<?php
if($result_count != 0){
?>			
	<input type="hidden" value="orderPlace" name="orderPlace">
                  <div class="list-cart-block">
                    <ul>
		<?php	
				$totalSum = array();
				foreach( $result as $print ){
					$boeketproduct = $print->boeketproduct;
					$prefer = $print->prefer;
					$numberCard = $print->numberCard;
					$cardWords = $print->cardWords;
					$priceExplode = explode("€",$boeketproduct);
					$price = $priceExplode[1];
					$finalprice = $price * $numberCard;
					$totalSum[]=$finalprice;
	?>					
					<input type="hidden" value="<?php echo $boeketproduct;?>" name="orderboeket[]">
					<input type="hidden" value="€<?php echo $finalprice;?>" name="orderPrice[]">
					<input type="hidden" value="<?php echo $cardWords;?>" name="orderCardWords[]">
					<input type="hidden" value="<?php echo $prefer;?>" name="orderPrefer[]">
                      <li>
                        <h3><a href="javascript:void(0);"><?php echo $boeketproduct;?></a></h3>  
                        <span>€<?php echo $finalprice;?></span>
                        <p><?php echo $cardWords;?></p>
                        <button class="btn-remove"><a href="static/wp-bbb/snel-bestellen/?remove_id=<?php echo $print->id;?>">&times;</a></button>
                      </li>
			<?php
			}
			?>		                    
                    </ul>
                  </div>
                  <div class="checkout-subtotal-block block-subtotal">
                    <ul>
                      <li>
                        <span>Subtotaal</span>
                        <span class="value"> €<?php echo array_sum($totalSum);?></span>
                      </li>
                    <!--  <li>
                        <span>Shipping</span>
                        <span class="value">-</span>
                      </li>-->
                    </ul>
                  </div>
				  <input type="hidden" value="€<?php echo array_sum($totalSum);?>" name="totalPrice">
                  <div class="total-checkout-block block-subtotal">
                    <ul>
                      <li>
                        <span>Totaal</span>
                        <span class="value">€<?php echo array_sum($totalSum);?></span>
                      </li>
                    </ul>
                  </div>

					<div  class="cashOnDelivery">
						<ul class="wc_payment_methods payment_methods methods">
						<li class="wc_payment_method payment_method_cod">
							<input id="payment_method_cod" type="radio" class="input-radio" name="payment_method" value="cod" checked="checked" data-order_button_text="">
							<label for="payment_method_cod">
								Contant </label>
									<div class="payment_box payment_method_cod">
									<p>Betaal contact bij levering/ophalen</p>
								</div>
							</li>
						</ul>
					  </div>	
				   <input type="submit" name="deliveryButton"value="Bestelling Plaatsen" class="btn-primary-red">
<?php
}
if(isset($_GET['successorder'])){
?>	
			
<div class="sucessMessage">
<h3 style="color:green;">Bedankt dat we binnenkort contact met u opnemen ...</h3>
</div>	
<?PHP
}
?>
                </div>
              </div>
		
		
            </div>
          </div>
        </section>
	</form>		
       
<?php get_footer(); ?>