<?php
/**
 * Template name: shop
 */



get_header(); ?>
<section class="page-title-block aos-init aos-animate" data-aos="fade-in" data-aos-duration="600" data-aos-delay="100ms">
          <div class="container">
            <h1>Shop</h1>
          </div>
        </section>
<section class="product-listing">
          <div class="container">
            <div class="row">
              <div class="col-sm-3 filter-block aos-init aos-animate" data-aos="fade-in" data-aos-duration="600" data-aos-delay="100ms">
                <aside>
                  <div class="title-block-filter">
                    <h3>Filters</h3>
                      <a class="resetButton" href="javascript:void(0);">Reset</a>
                  </div>
                  <div class="filter-block-list">
                    <ul>
          <?php
  $args = array(
     'hierarchical' => 1,
     'show_option_none' => '',
     'hide_empty' => 0,
     'parent' => 32,
     'taxonomy' => 'product_cat'
  );
  $subcats = get_categories($args);
    foreach ($subcats as $sc) {
      ?>
                      <li>
                        <label class="custom-checkbox">
                         <input type="checkbox" class="filterCatagories" id="<?php echo $sc->term_id;?>" name="filterCheckbox">
                           <span><?php echo $sc->name;?></span>
                        </label>
                      </li>
     <?php
    }
    ?>
                    </ul>
                  </div>
                  <div class="title-block-filter">
                    <h3>Assortiment</h3>
                  </div>
                  <div class="filter-block-list">
                    <ul>
      <?php
  $args = array(
       'hierarchical' => 1,
       'show_option_none' => '',
       'hide_empty' => 0,
       'parent' => 33,
       'taxonomy' => 'product_cat'
    );
  $subcats = get_categories($args);
  /* print_r($subcats); */ 
      foreach ($subcats as $sc) {
      ?>
                      <li>
                        <label class="custom-checkbox">
                          <input type="checkbox" class="filterCatagories" id="<?php echo $sc->term_id;?>" name="filterCheckbox">
                          <span><?php echo $sc->name;?></span>
                        </label>
                      </li>
 <?php
    }
    ?>
      
                    </ul>
                  </div>
                  <div class="apply-filter-mob">
                    <a href="javascript:void(0);" class="apply-filter">Apply</a>
                    <a href="javascript:void(0);" class="cancel-filter">Cancel</a>
                  </div>
                </aside>
              </div>
              <div class="col-sm-9">
                <div class="list-product-block">
                  <div class="sort-by-block aos-init aos-animate" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms">
                    <div class="filter-btn-mob">Filter</div>
					  <div class="mob-sort">
						  <label>Sorteer op:</label>
                    <div class="sort-select">
                      <select id="sel1">
                        <option value="newpopular">Nieuw en populair</option>
                        <option <?php if($_GET['orderby'] == "ASC"){?>
            selected
            <?php } ?> value="lowtohiegh" >Laag naar hoog</option>
                        <option <?php if($_GET['orderby'] == "DESC"){?>
            selected
            <?php } ?> value="heighttolow">Hoog naar laag</option>
                      </select>
                    </div>
					  </div> 
                    
                  </div>
          <input type="hidden" class="price_val" value="<?php echo $_GET['price'];?>">
          <input type="hidden" class="orderby_val" value="<?php echo $_GET['orderby'];?>">
                  <div class="row product_id">
                    <?php
    $meta_key = $_GET['price'];
    //$meta_key ="_price";
    $orderby = $_GET['orderby'];
    //$orderby = "ASC";
        $args = array(
          'post_type' => 'product',
          'orderby' => 'meta_value_num',
          'meta_key' => $meta_key,
          'order' => $orderby,
          'posts_per_page' => 9
        ); 
$i=0;
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post();
          global $product;
        $_product = wc_get_product( $product->get_id());      
         $product->get_id();
        ?>
                    <div class="col-sm-4">
                      <a href="<?php echo get_permalink( $product->get_id() );?>" class="list-product-ui aos-init aos-animate" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms">
                        <figure>
          <?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $loop->post->ID ), 'single-post-thumbnail' );?>
            <img src="<?php  echo $image[0]; ?>" data-id="<?php echo $loop->post->ID; ?>">
                        </figure>
                        <div class="figure-content">
                          <div class="price-value">
                            <label>Vanaf</label>
                            <span><?php echo get_woocommerce_currency_symbol();?> <?php echo $_product->get_price();?> </span>
                          </div> 
                          <div class="name-flower"><?php echo get_the_title();?></div>
                        </div>
                      </a>
                    </div>
        <?php   
          $i++;     
      endwhile;
      wp_reset_query();?> 
                  </div>
<?php
                
        $args = array(
          'post_type' => 'product',
          'posts_per_page' => -1
        ); 
$b=0;
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post();
          $b++;     
        endwhile;
      wp_reset_query();   
 $sumpro = (int)$b - (int)9;
if($sumpro < 1){}
else{      
?>          
                  <div class="load-more-product aos-init aos-animate load-more" data-offset="<?php echo $i;?>" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms">
                    <a href="javascript:void(0);" class="loadMoreCount">Laad meer producten (<?php echo $sumpro;?>)</a>
                  </div>
<?php
}
?>          
                </div>
              </div>
            </div>
          </div>
        </section>
     <div  class="loader"></div>
<?php get_footer(); ?>