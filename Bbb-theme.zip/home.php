<?php
/**
 * Template name: home
 */

get_header(); ?>
 <section class="hero-section" style="background-image: url(<?php echo get_template_directory_uri();?>/images/banner-bg.jpg)">
          <div class="container">
            <div class="hero-slider">
              <div class="item"  >
                <div class="row">
                  <div class="col-sm-6 align-self-center">
                    <div class="hero-block-left">
					<?php dynamic_sidebar('sidebar-12');?>
                    </div>
                  </div>
                  <!--<div class="col-sm-6 align-self-center">
                    <div class="slider-img">
                      <img src="<?php echo get_template_directory_uri();?>/images/slider-img-1.png" alt="">
                    </div>
                  </div>-->
                </div>
              </div>
              <div class="item" style="display:none;">
                <div class="row">
                  <div class="col-sm-6 align-self-center">
                    <div class="hero-block-left">
                      <h2>The point of using Lorem Ipsum</h2>
                      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                      <div class="block-banner-btn">
                        <a href="javascript:void(0);" class="btn btn-primary-red">Snel bestellen</a>
                        <a href="javascript:void(0);" class="btn btn-primary-white">Rondkijken</a>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-6 align-self-center">
                    <div class="slider-img">
                      <img src="<?php echo get_template_directory_uri();?>/images/slider-img-2.png" alt="">
                    </div>
                  </div>
                </div>
              </div>
              <div class="item" style="display:none;">
                <div class="row">
                  <div class="col-sm-6 align-self-center">
                    <div class="hero-block-left">
                      <h2>Lorem Ipsum, you need to be sure.</h2>
                      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                      <div class="block-banner-btn">
                        <a href="javascript:void(0);" class="btn btn-primary-red">Snel bestellen</a>
                        <a href="javascript:void(0);" class="btn btn-primary-white">Rondkijken</a>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-6 align-self-center">
                    <div class="slider-img">
                      <img src="<?php echo get_template_directory_uri();?>/images/slider-img-3.png" alt="">
                    </div>
                  </div>
                </div>
              </div>
              <div class="item" style="display:none;">
                <div class="row">
                  <div class="col-sm-6 align-self-center">
                    <div class="hero-block-left">
                      <h2>Lorem ipsum dolor sit amet, consectetur</h2>
                      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                      <div class="block-banner-btn">
                        <a href="javascript:void(0);" class="btn btn-primary-red">Snel bestellen</a>
                        <a href="javascript:void(0);" class="btn btn-primary-white">Rondkijken</a>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-6 align-self-center">
                    <div class="slider-img">
                      <img src="<?php echo get_template_directory_uri();?>/images/slider-img-4.png" alt="">
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="scroll-banner">
            <img src="<?php echo get_template_directory_uri();?>/images/mouse.png" alt="">
          </div>
        </section>
<?php 
				while ( have_posts() ) : the_post();
				?>
		<section class="block-section-2">
          <div class="container">
            <div class="row">
              <div class="col-sm-6">
                <div class="block-section-2-left" data-aos="fade-right" data-aos-duration="600">
        	<?PHP
				the_content();
				 ?>

				<a href="<?php echo get_post_meta(get_the_ID(), 'mogelijkheden Btn Url', TRUE);?>" class="btn-arrow-border"><?php echo get_post_meta(get_the_ID(), 'mogelijkheden button', TRUE);?><span class="arrow-right"></span></a>
                </div>
              </div>
              <div class="col-sm-6" data-aos="fade-left" data-aos-duration="600">
                <div class="image-blog-2">
                  <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="">
                </div>
              </div>
            </div>
          </div>
        </section>
		<?PHP
			endwhile;  
				wp_reset_query(); ?>
        <section class="order-timing" style="background-image: url(<?php echo get_template_directory_uri();?>/images/order-bg.jpg);">
          <div class="container">
<?php dynamic_sidebar('sidebar-2');?>
          </div>
        </section>
        <section class="flower--styling" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100">
          <div class="container">
            <div class="row">
			
      		  <div class="col-sm-6">
                <div class="img-style-block">
                  <a href="<?php echo get_post(9)->guid; ?>" class="img-full-style">
                    <img src="<?php echo get_post_meta(9, 'homeImage', TRUE);?>">
                    <span class="title-flower"><?php echo get_post(9)->post_title; ?></span>
                  </a>
                </div>
              </div>
              <div class="col-sm-6">
				<div class="img-style-block">
                  <a href="<?php echo get_post(11)->guid; ?>" class="img-full-style">
                    <img src="<?php echo get_post_meta(11, 'homeImage', TRUE);?>">
                    <span class="title-flower"><?php echo get_post(11)->post_title; ?></span>
                  </a>
                </div>
                 <div class="img-style-block">
                  <a href="<?php echo get_post(14)->guid; ?>" class="img-full-style">
                    <img src="<?php echo get_post_meta(14, 'homeImage', TRUE);?>">
                    <span class="title-flower"><?php echo get_post(14)->post_title; ?></span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section class="our-flowers">
          <div class="container">
            <div class="head-border-main" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100">
              <h2>ONZE BLOEMEN</h2>
            </div>
            <div class="our-flowers-block">
              <div class="row">
			  					<?php
				$args = array(
					'post_type' => 'product',
					'orderby'   => 'title',
					'order'    =>  'DESC',
					'posts_per_page' =>4
				);

				$loop = new WP_Query( $args );
				while ( $loop->have_posts() ) : $loop->the_post();
					global $product;
				$_product = wc_get_product( $product->get_id());			
				 $product->get_id();
				?>
                <div class="col-sm-3" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100">
                  <div class="our-flowers-box">
                    <figure>
					<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $product->get_id() ), 'single-post-thumbnail' );
					/* echo "<pre>";
					print_r($image); */?>
                      <a href="<?php echo get_permalink( $product->get_id() );?>">
                        <img src="<?php echo $image[0];?>">
                      </a>
                    </figure>
                    <figcaption>
					
                      <h3 class="name-flower"><a href="<?php echo get_permalink( $product->get_id() );?>"><?php echo get_the_title();?></a></h3>
                      <span class="price-flower">€ <?php echo $_product->get_price();?></span>
                      <a href="<?php echo get_permalink( $product->get_id() );?>" class="btn-cart">	
						<img src="<?php echo get_template_directory_uri();?>/images/cart-icon.png" alt=""><span>Bestellen</span></a>
                    </figcaption>
                  </div>
                </div>
				<?php	  
						
			endwhile;
			wp_reset_query();?>	



                <div class="col-sm-12 text-center view-all-action" data-aos="fade-in" data-aos-duration="600" data-aos-delay="400">
                  <a href="/static/wp-bbb/shop-filters/" class="btn-arrow-border">Bekijk alle boeketten<span class="arrow-right"></span></a>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="instagram-gallary">
          <div class="container">
            <div class="head-border-main" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100">
              <h2>Instagram</h2>
            </div>
            <div class="row" data-aos="fade-up" data-aos-duration="600" data-aos-delay="200">
			<?php echo do_shortcode('[wdi_feed id="1"]');?>
            </div>
          </div>
        </section>
<?php get_footer(); ?>
