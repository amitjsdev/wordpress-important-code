<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
        <section class="error-page">
          <div class="container">
           <?php dynamic_sidebar('sidebar-10');;?> 
          </div>
        </section>

<?php get_footer(); ?>
