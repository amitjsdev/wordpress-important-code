<?php
/**
 * The template for displaying search results pages
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
 
	<section id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		<?php if ( have_posts() ) : ?>
 <section class="our-flowers">
          <div class="container">
            <div class="head-border-main searchresultheader" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100">
              <h2><?php printf( __( 'Zoekresultaten voor: %s', 'twentysixteen' ), '<span>' . esc_html( get_search_query() ) . '</span>' ); ?></h2>
            </div>
            <div class="our-flowers-block">
              <div class="row">
			  
			  
			

			<?php
			// Start the loop.
			while ( have_posts() ) : the_post();
?>

			<?php
				get_template_part( 'template-parts/content', 'search' );
?>
<?php
			endwhile;

			// Previous/next page navigation.
			the_posts_pagination( array(
				'prev_text'          => __( 'Previous page', 'twentysixteen' ),
				'next_text'          => __( 'Next page', 'twentysixteen' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>',
			) );
?>

					</div>
				</div>
			</div>
		</section>
		<?php
		else :
			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>

		</main><!-- .site-main -->
	</section><!-- .content-area -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
