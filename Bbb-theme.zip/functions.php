<?php
/**
 * Twenty Sixteen functions and definitions
 *
 * Set up the theme and provides some helper functions, which are used in the
 * theme as custom template tags. Others are attached to action and filter
 * hooks in WordPress to change core functionality.
 *
 * When using a child theme you can override certain functions (those wrapped
 * in a function_exists() call) by defining them first in your child theme's
 * functions.php file. The child theme's functions.php file is included before
 * the parent theme's file, so the child theme functions would be used.
 *
 * @link https://codex.wordpress.org/Theme_Development
 * @link https://codex.wordpress.org/Child_Themes
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are
 * instead attached to a filter or action hook.
 *
 * For more information on hooks, actions, and filters,
 * {@link https://codex.wordpress.org/Plugin_API}
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

/**
 * Twenty Sixteen only works in WordPress 4.4 or later.
 */
if ( version_compare( $GLOBALS['wp_version'], '4.4-alpha', '<' ) ) {
	require get_template_directory() . '/inc/back-compat.php';
}

if ( ! function_exists( 'twentysixteen_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 *
 * Create your own twentysixteen_setup() function to override in a child theme.
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed at WordPress.org. See: https://translate.wordpress.org/projects/wp-themes/twentysixteen
	 * If you're building a theme based on Twenty Sixteen, use a find and replace
	 * to change 'twentysixteen' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'twentysixteen' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for custom logo.
	 *
	 *  @since Twenty Sixteen 1.2
	 */
	add_theme_support( 'custom-logo', array(
		'height'      => 240,
		'width'       => 240,
		'flex-height' => true,
	) );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 1200, 9999 );

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'twentysixteen' ),
		'social'  => __( 'Social Links Menu', 'twentysixteen' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	/*
	 * Enable support for Post Formats.
	 *
	 * See: https://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'aside',
		'image',
		'video',
		'quote',
		'link',
		'gallery',
		'status',
		'audio',
		'chat',
	) );

	/*
	 * This theme styles the visual editor to resemble the theme style,
	 * specifically font, colors, icons, and column width.
	 */
	add_editor_style( array( 'css/editor-style.css', twentysixteen_fonts_url() ) );

	// Load regular editor styles into the new block-based editor.
	add_theme_support( 'editor-styles' );

	// Load default block styles.
	add_theme_support( 'wp-block-styles' );

	// Add support for responsive embeds.
	add_theme_support( 'responsive-embeds' );

	// Add support for custom color scheme.
	add_theme_support( 'editor-color-palette', array(
		array(
			'name'  => __( 'Dark Gray', 'twentysixteen' ),
			'slug'  => 'dark-gray',
			'color' => '#1a1a1a',
		),
		array(
			'name'  => __( 'Medium Gray', 'twentysixteen' ),
			'slug'  => 'medium-gray',
			'color' => '#686868',
		),
		array(
			'name'  => __( 'Light Gray', 'twentysixteen' ),
			'slug'  => 'light-gray',
			'color' => '#e5e5e5',
		),
		array(
			'name'  => __( 'White', 'twentysixteen' ),
			'slug'  => 'white',
			'color' => '#fff',
		),
		array(
			'name'  => __( 'Blue Gray', 'twentysixteen' ),
			'slug'  => 'blue-gray',
			'color' => '#4d545c',
		),
		array(
			'name'  => __( 'Bright Blue', 'twentysixteen' ),
			'slug'  => 'bright-blue',
			'color' => '#007acc',
		),
		array(
			'name'  => __( 'Light Blue', 'twentysixteen' ),
			'slug'  => 'light-blue',
			'color' => '#9adffd',
		),
		array(
			'name'  => __( 'Dark Brown', 'twentysixteen' ),
			'slug'  => 'dark-brown',
			'color' => '#402b30',
		),
		array(
			'name'  => __( 'Medium Brown', 'twentysixteen' ),
			'slug'  => 'medium-brown',
			'color' => '#774e24',
		),
		array(
			'name'  => __( 'Dark Red', 'twentysixteen' ),
			'slug'  => 'dark-red',
			'color' => '#640c1f',
		),
		array(
			'name'  => __( 'Bright Red', 'twentysixteen' ),
			'slug'  => 'bright-red',
			'color' => '#ff675f',
		),
		array(
			'name'  => __( 'Yellow', 'twentysixteen' ),
			'slug'  => 'yellow',
			'color' => '#ffef8e',
		),
	) );

	// Indicate widget sidebars can use selective refresh in the Customizer.
	add_theme_support( 'customize-selective-refresh-widgets' );
}
endif; // twentysixteen_setup
add_action( 'after_setup_theme', 'twentysixteen_setup' );

/**
 * Sets the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'twentysixteen_content_width', 840 );
}
add_action( 'after_setup_theme', 'twentysixteen_content_width', 0 );

/**
 * Registers a widget area.
 *
 * @link https://developer.wordpress.org/reference/functions/register_sidebar/
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_widgets_init() {
/* 	register_sidebar( array(
		'name'          => __( 'Sidebar', 'twentysixteen' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) ); */
	register_sidebar( array(
		'name'          => __( 'Home Order Contact', 'twentysixteen' ),
		'id'            => 'sidebar-2',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
		register_sidebar( array(
		'name'          => __( 'Footer Ralph Thought', 'twentysixteen' ),
		'id'            => 'sidebar-3',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
		register_sidebar( array(
		'name'          => __( 'Footer First Section', 'twentysixteen' ),
		'id'            => 'sidebar-4',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
		register_sidebar( array(
		'name'          => __( 'Footer Menu', 'twentysixteen' ),
		'id'            => 'sidebar-5',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer Timings', 'twentysixteen' ),
		'id'            => 'sidebar-6',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => __( 'Copy Right', 'twentysixteen' ),
		'id'            => 'sidebar-7',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => __( 'Funeral Contact Info', 'twentysixteen' ),
		'id'            => 'sidebar-8',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => __( 'Contact Map', 'twentysixteen' ),
		'id'            => 'sidebar-9',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );	
		register_sidebar( array(
		'name'          => __( '404 error', 'twentysixteen' ),
		'id'            => 'sidebar-10',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => __( 'Other pages Logo', 'twentysixteen' ),
		'id'            => 'sidebar-11',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
		register_sidebar( array(
		'name'          => __( 'Home page sliderText', 'twentysixteen' ),
		'id'            => 'sidebar-12',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
			register_sidebar( array(
		'name'          => __( 'Home page sliderText', 'twentysixteen' ),
		'id'            => 'sidebar-12',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => __( 'About page sliderText', 'twentysixteen' ),
		'id'            => 'sidebar-13',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => __( 'Empty Cart', 'twentysixteen' ),
		'id'            => 'sidebar-14',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => __( 'Privacy Policy', 'twentysixteen' ),
		'id'            => 'sidebar-15',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'twentysixteen_widgets_init' );

if ( ! function_exists( 'twentysixteen_fonts_url' ) ) :
/**
 * Register Google fonts for Twenty Sixteen.
 *
 * Create your own twentysixteen_fonts_url() function to override in a child theme.
 *
 * @since Twenty Sixteen 1.0
 *
 * @return string Google fonts URL for the theme.
 */
function twentysixteen_fonts_url() {
	$fonts_url = '';
	$fonts     = array();
	$subsets   = 'latin,latin-ext';

	/* translators: If there are characters in your language that are not supported by Merriweather, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== _x( 'on', 'Merriweather font: on or off', 'twentysixteen' ) ) {
		$fonts[] = 'Merriweather:400,700,900,400italic,700italic,900italic';
	}

	/* translators: If there are characters in your language that are not supported by Montserrat, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== _x( 'on', 'Montserrat font: on or off', 'twentysixteen' ) ) {
		$fonts[] = 'Montserrat:400,700';
	}

	/* translators: If there are characters in your language that are not supported by Inconsolata, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== _x( 'on', 'Inconsolata font: on or off', 'twentysixteen' ) ) {
		$fonts[] = 'Inconsolata:400';
	}

	if ( $fonts ) {
		$fonts_url = add_query_arg( array(
			'family' => urlencode( implode( '|', $fonts ) ),
			'subset' => urlencode( $subsets ),
		), 'https://fonts.googleapis.com/css' );
	}

	return $fonts_url;
}
endif;

/**
 * Handles JavaScript detection.
 *
 * Adds a `js` class to the root `<html>` element when JavaScript is detected.
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_javascript_detection() {
	echo "<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>\n";
}
add_action( 'wp_head', 'twentysixteen_javascript_detection', 0 );

/**
 * Enqueues scripts and styles.
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_scripts() {
	// Add custom fonts, used in the main stylesheet.
	wp_enqueue_style( 'twentysixteen-fonts', twentysixteen_fonts_url(), array(), null );

	// Add Genericons, used in the main stylesheet.
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/genericons/genericons.css', array(), '3.4.1' );

	// Theme stylesheet.
	wp_enqueue_style( 'twentysixteen-style', get_stylesheet_uri() );

	// Theme block stylesheet.
	wp_enqueue_style( 'twentysixteen-block-style', get_template_directory_uri() . '/css/blocks.css', array( 'twentysixteen-style' ), '20181018' );

	// Load the Internet Explorer specific stylesheet.
	wp_enqueue_style( 'twentysixteen-ie', get_template_directory_uri() . '/css/ie.css', array( 'twentysixteen-style' ), '20160816' );
	wp_style_add_data( 'twentysixteen-ie', 'conditional', 'lt IE 10' );

	// Load the Internet Explorer 8 specific stylesheet.
	wp_enqueue_style( 'twentysixteen-ie8', get_template_directory_uri() . '/css/ie8.css', array( 'twentysixteen-style' ), '20160816' );
	wp_style_add_data( 'twentysixteen-ie8', 'conditional', 'lt IE 9' );

	// Load the Internet Explorer 7 specific stylesheet.
	wp_enqueue_style( 'twentysixteen-ie7', get_template_directory_uri() . '/css/ie7.css', array( 'twentysixteen-style' ), '20160816' );
	wp_style_add_data( 'twentysixteen-ie7', 'conditional', 'lt IE 8' );

	// Load the html5 shiv.
	wp_enqueue_script( 'twentysixteen-html5', get_template_directory_uri() . '/js/html5.js', array(), '3.7.3' );
	wp_script_add_data( 'twentysixteen-html5', 'conditional', 'lt IE 9' );

	wp_enqueue_script( 'twentysixteen-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20160816', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	if ( is_singular() && wp_attachment_is_image() ) {
		wp_enqueue_script( 'twentysixteen-keyboard-image-navigation', get_template_directory_uri() . '/js/keyboard-image-navigation.js', array( 'jquery' ), '20160816' );
	}
	wp_enqueue_script( 'twentysixteen-script', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ), '20160816', true );

	wp_localize_script( 'twentysixteen-script', 'screenReaderText', array(
		'expand'   => __( 'expand child menu', 'twentysixteen' ),
		'collapse' => __( 'collapse child menu', 'twentysixteen' ),
	) );
}
add_action( 'wp_enqueue_scripts', 'twentysixteen_scripts' );

/**
 * Enqueue styles for the block-based editor.
 *
 * @since Twenty Sixteen 1.6
 */
function twentysixteen_block_editor_styles() {
	// Block styles.
	wp_enqueue_style( 'twentysixteen-block-editor-style', get_template_directory_uri() . '/css/editor-blocks.css' );
	// Add custom fonts.
	wp_enqueue_style( 'twentysixteen-fonts', twentysixteen_fonts_url(), array(), null );
}
add_action( 'enqueue_block_editor_assets', 'twentysixteen_block_editor_styles' );

/**
 * Adds custom classes to the array of body classes.
 *
 * @since Twenty Sixteen 1.0
 *
 * @param array $classes Classes for the body element.
 * @return array (Maybe) filtered body classes.
 */
function twentysixteen_body_classes( $classes ) {
	// Adds a class of custom-background-image to sites with a custom background image.
	if ( get_background_image() ) {
		$classes[] = 'custom-background-image';
	}

	// Adds a class of group-blog to sites with more than 1 published author.
	if ( is_multi_author() ) {
		$classes[] = 'group-blog';
	}

	// Adds a class of no-sidebar to sites without active sidebar.
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}

	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	return $classes;
}
add_filter( 'body_class', 'twentysixteen_body_classes' );

/**
 * Converts a HEX value to RGB.
 *
 * @since Twenty Sixteen 1.0
 *
 * @param string $color The original color, in 3- or 6-digit hexadecimal form.
 * @return array Array containing RGB (red, green, and blue) values for the given
 *               HEX code, empty array otherwise.
 */
function twentysixteen_hex2rgb( $color ) {
	$color = trim( $color, '#' );

	if ( strlen( $color ) === 3 ) {
		$r = hexdec( substr( $color, 0, 1 ).substr( $color, 0, 1 ) );
		$g = hexdec( substr( $color, 1, 1 ).substr( $color, 1, 1 ) );
		$b = hexdec( substr( $color, 2, 1 ).substr( $color, 2, 1 ) );
	} else if ( strlen( $color ) === 6 ) {
		$r = hexdec( substr( $color, 0, 2 ) );
		$g = hexdec( substr( $color, 2, 2 ) );
		$b = hexdec( substr( $color, 4, 2 ) );
	} else {
		return array();
	}

	return array( 'red' => $r, 'green' => $g, 'blue' => $b );
}

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Add custom image sizes attribute to enhance responsive image functionality
 * for content images
 *
 * @since Twenty Sixteen 1.0
 *
 * @param string $sizes A source size value for use in a 'sizes' attribute.
 * @param array  $size  Image size. Accepts an array of width and height
 *                      values in pixels (in that order).
 * @return string A source size value for use in a content image 'sizes' attribute.
 */
function twentysixteen_content_image_sizes_attr( $sizes, $size ) {
	$width = $size[0];

	if ( 840 <= $width ) {
		$sizes = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 1362px) 62vw, 840px';
	}

	if ( 'page' === get_post_type() ) {
		if ( 840 > $width ) {
			$sizes = '(max-width: ' . $width . 'px) 85vw, ' . $width . 'px';
		}
	} else {
		if ( 840 > $width && 600 <= $width ) {
			$sizes = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 984px) 61vw, (max-width: 1362px) 45vw, 600px';
		} elseif ( 600 > $width ) {
			$sizes = '(max-width: ' . $width . 'px) 85vw, ' . $width . 'px';
		}
	}

	return $sizes;
}
add_filter( 'wp_calculate_image_sizes', 'twentysixteen_content_image_sizes_attr', 10 , 2 );

/**
 * Add custom image sizes attribute to enhance responsive image functionality
 * for post thumbnails
 *
 * @since Twenty Sixteen 1.0
 *
 * @param array $attr Attributes for the image markup.
 * @param int   $attachment Image attachment ID.
 * @param array $size Registered image size or flat array of height and width dimensions.
 * @return array The filtered attributes for the image markup.
 */
function twentysixteen_post_thumbnail_sizes_attr( $attr, $attachment, $size ) {
	if ( 'post-thumbnail' === $size ) {
		if ( is_active_sidebar( 'sidebar-1' ) ) {
			$attr['sizes'] = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 984px) 60vw, (max-width: 1362px) 62vw, 840px';
		} else {
			$attr['sizes'] = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 1362px) 88vw, 1200px';
		}
	}
	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'twentysixteen_post_thumbnail_sizes_attr', 10 , 3 );

/**
 * Modifies tag cloud widget arguments to display all tags in the same font size
 * and use list format for better accessibility.
 *
 * @since Twenty Sixteen 1.1
 *
 * @param array $args Arguments for tag cloud widget.
 * @return array The filtered arguments for tag cloud widget.
 */
function twentysixteen_widget_tag_cloud_args( $args ) {
	$args['largest']  = 1;
	$args['smallest'] = 1;
	$args['unit']     = 'em';
	$args['format']   = 'list';

	return $args;
}
add_filter( 'widget_tag_cloud_args', 'twentysixteen_widget_tag_cloud_args' );

/////////////////////////////////////////////////////////

function custom_post_type_office_stylings() {
// Set UI labels for Custom Post Type
    $labels = array(

        'name'                => _x( 'Office Styling', 'Post Type General Name', 'infinoax' ),

        'singular_name'       => _x( 'Office Styling', 'Post Type Singular Name', 'infinoax' ),

        'menu_name'           => __( 'Office Styling', 'infinoax' ),

        'parent_item_colon'   => __( 'Parent Office Styling', 'infinoax' ),

        'all_items'           => __( 'All Office Styling', 'infinoax' ),

        'view_item'           => __( 'View Office Styling', 'infinoax' ),

        'add_new_item'        => __( 'Add New Office Styling', 'infinoax' ),

        'add_new'             => __( 'Add New', 'infinoax' ),

        'edit_item'           => __( 'Edit Office Styling', 'infinoax' ),

        'update_item'         => __( 'Update Office Styling', 'infinoax' ),

        'search_items'        => __( 'Search Office Styling', 'infinoax' ),

        'not_found'           => __( 'Not Found', 'infinoax' ),

        'not_found_in_trash'  => __( 'Not found in Trash', 'infinoax' ),

    );

// Set other options for Custom Post Type

    $args = array(
        'label'               => __( 'Office Styling', 'infinoax' ),
        'description'         => __( 'Office Styling news and reviews', 'infinoax' ),

        'labels'              => $labels,

        // Features this CPT supports in Post Editor

        'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),

        'taxonomies'          => array( 'genres' ),

        /* A hierarchical CPT is like Pages and can have
35
        * Parent and child items. A non-hierarchical CPT
36
        * is like Posts.
37
        */ 

        'hierarchical'        => false,

        'public'              => true,

        'show_ui'             => true,

        'show_in_menu'        => true,

        'show_in_nav_menus'   => true,

        'show_in_admin_bar'   => true,

        'menu_position'       => 5,

        'can_export'          => true,

        'has_archive'         => true,

        'exclude_from_search' => false,

        'publicly_queryable'  => true,

        'capability_type'     => 'page',

    );

    // Registering your Custom Post Type

    register_post_type( 'Office Styling', $args );
}

add_action( 'init', 'custom_post_type_office_stylings', 0 );
//////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////

function custom_post_type_Rouwbloemen() {
// Set UI labels for Custom Post Type
    $labels = array(

        'name'                => _x( 'Rouwbloemen', 'Post Type General Name', 'infinoax' ),

        'singular_name'       => _x( 'Rouwbloemen', 'Post Type Singular Name', 'infinoax' ),

        'menu_name'           => __( 'Rouwbloemen', 'infinoax' ),

        'parent_item_colon'   => __( 'Parent Rouwbloemen', 'infinoax' ),

        'all_items'           => __( 'All Rouwbloemen', 'infinoax' ),

        'view_item'           => __( 'View Rouwbloemen', 'infinoax' ),

        'add_new_item'        => __( 'Add New Rouwbloemen', 'infinoax' ),

        'add_new'             => __( 'Add New', 'infinoax' ),

        'edit_item'           => __( 'Edit Rouwbloemen', 'infinoax' ),

        'update_item'         => __( 'Update Rouwbloemen', 'infinoax' ),

        'search_items'        => __( 'Search Rouwbloemen', 'infinoax' ),

        'not_found'           => __( 'Not Found', 'infinoax' ),

        'not_found_in_trash'  => __( 'Not found in Trash', 'infinoax' ),

    );

// Set other options for Custom Post Type

    $args = array(
        'label'               => __( 'Rouwbloemen', 'infinoax' ),
        'description'         => __( 'Rouwbloemen news and reviews', 'infinoax' ),

        'labels'              => $labels,

        // Features this CPT supports in Post Editor

        'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),

        'taxonomies'          => array( 'genres' ),

        /* A hierarchical CPT is like Pages and can have
35
        * Parent and child items. A non-hierarchical CPT
36
        * is like Posts.
37
        */ 

        'hierarchical'        => false,

        'public'              => true,

        'show_ui'             => true,

        'show_in_menu'        => true,

        'show_in_nav_menus'   => true,

        'show_in_admin_bar'   => true,

        'menu_position'       => 5,

        'can_export'          => true,

        'has_archive'         => true,

        'exclude_from_search' => false,

        'publicly_queryable'  => true,

        'capability_type'     => 'page',

    );

    // Registering your Custom Post Type

    register_post_type( 'Rouwbloemen', $args );
}

add_action( 'init', 'custom_post_type_Rouwbloemen', 0 );
/////////////////////////////////////////////////////////

function custom_post_type_Wonen() {
// Set UI labels for Custom Post Type
    $labels = array(

        'name'                => _x( 'Wonen', 'Post Type General Name', 'infinoax' ),

        'singular_name'       => _x( 'Wonen', 'Post Type Singular Name', 'infinoax' ),

        'menu_name'           => __( 'Wonen', 'infinoax' ),

        'parent_item_colon'   => __( 'Parent Wonen', 'infinoax' ),

        'all_items'           => __( 'All Wonen', 'infinoax' ),

        'view_item'           => __( 'View Wonen', 'infinoax' ),

        'add_new_item'        => __( 'Add New Wonen', 'infinoax' ),

        'add_new'             => __( 'Add New', 'infinoax' ),

        'edit_item'           => __( 'Edit Wonen', 'infinoax' ),

        'update_item'         => __( 'Update Wonen', 'infinoax' ),

        'search_items'        => __( 'Search Wonen', 'infinoax' ),

        'not_found'           => __( 'Not Found', 'infinoax' ),

        'not_found_in_trash'  => __( 'Not found in Trash', 'infinoax' ),

    );

// Set other options for Custom Post Type

    $args = array(
        'label'               => __( 'Wonen', 'infinoax' ),
        'description'         => __( 'Wonen news and reviews', 'infinoax' ),

        'labels'              => $labels,

        // Features this CPT supports in Post Editor

        'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),

        'taxonomies'          => array( 'genres' ),

        /* A hierarchical CPT is like Pages and can have
35
        * Parent and child items. A non-hierarchical CPT
36
        * is like Posts.
37
        */ 

        'hierarchical'        => false,

        'public'              => true,

        'show_ui'             => true,

        'show_in_menu'        => true,

        'show_in_nav_menus'   => true,

        'show_in_admin_bar'   => true,

        'menu_position'       => 5,

        'can_export'          => true,

        'has_archive'         => true,

        'exclude_from_search' => false,

        'publicly_queryable'  => true,

        'capability_type'     => 'page',

    );

    // Registering your Custom Post Type

    register_post_type( 'Wonen', $args );
}

add_action( 'init', 'custom_post_type_Wonen', 0 );
/////////////////////////////////////////////////////////

function custom_post_type_bruidsbloemen() {
// Set UI labels for Custom Post Type
    $labels = array(

        'name'                => _x( 'bruidsbloemen', 'Post Type General Name', 'infinoax' ),

        'singular_name'       => _x( 'bruidsbloemen', 'Post Type Singular Name', 'infinoax' ),

        'menu_name'           => __( 'bruidsbloemen', 'infinoax' ),

        'parent_item_colon'   => __( 'Parent bruidsbloemen', 'infinoax' ),

        'all_items'           => __( 'All bruidsbloemen', 'infinoax' ),

        'view_item'           => __( 'View bruidsbloemen', 'infinoax' ),

        'add_new_item'        => __( 'Add New bruidsbloemen', 'infinoax' ),

        'add_new'             => __( 'Add New', 'infinoax' ),

        'edit_item'           => __( 'Edit bruidsbloemen', 'infinoax' ),

        'update_item'         => __( 'Update bruidsbloemen', 'infinoax' ),

        'search_items'        => __( 'Search bruidsbloemen', 'infinoax' ),

        'not_found'           => __( 'Not Found', 'infinoax' ),

        'not_found_in_trash'  => __( 'Not found in Trash', 'infinoax' ),

    );

// Set other options for Custom Post Type

    $args = array(
        'label'               => __( 'bruidsbloemen', 'infinoax' ),
        'description'         => __( 'bruidsbloemen news and reviews', 'infinoax' ),

        'labels'              => $labels,

        // Features this CPT supports in Post Editor

        'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),

        'taxonomies'          => array( 'genres' ),

        /* A hierarchical CPT is like Pages and can have
35
        * Parent and child items. A non-hierarchical CPT
36
        * is like Posts.
37
        */ 

        'hierarchical'        => false,

        'public'              => true,

        'show_ui'             => true,

        'show_in_menu'        => true,

        'show_in_nav_menus'   => true,

        'show_in_admin_bar'   => true,

        'menu_position'       => 5,

        'can_export'          => true,

        'has_archive'         => true,

        'exclude_from_search' => false,

        'publicly_queryable'  => true,

        'capability_type'     => 'page',

    );

    // Registering your Custom Post Type

    register_post_type( 'bruidsbloemen', $args );
}

add_action( 'init', 'custom_post_type_bruidsbloemen', 0 );
///////////////////////////////////
/////////////////////////////////////////////////////////

function custom_post_type_Kantoorstyling() {
// Set UI labels for Custom Post Type
    $labels = array(

        'name'                => _x( 'Kantoorstyling', 'Post Type General Name', 'infinoax' ),

        'singular_name'       => _x( 'Kantoorstyling', 'Post Type Singular Name', 'infinoax' ),

        'menu_name'           => __( 'Kantoorstyling', 'infinoax' ),

        'parent_item_colon'   => __( 'Parent Kantoorstyling', 'infinoax' ),

        'all_items'           => __( 'All Kantoorstyling', 'infinoax' ),

        'view_item'           => __( 'View Kantoorstyling', 'infinoax' ),

        'add_new_item'        => __( 'Add New Kantoorstyling', 'infinoax' ),

        'add_new'             => __( 'Add New', 'infinoax' ),

        'edit_item'           => __( 'Edit Kantoorstyling', 'infinoax' ),

        'update_item'         => __( 'Update Kantoorstyling', 'infinoax' ),

        'search_items'        => __( 'Search Kantoorstyling', 'infinoax' ),

        'not_found'           => __( 'Not Found', 'infinoax' ),

        'not_found_in_trash'  => __( 'Not found in Trash', 'infinoax' ),

    );

// Set other options for Custom Post Type

    $args = array(
        'label'               => __( 'Kantoorstyling', 'infinoax' ),
        'description'         => __( 'Kantoorstyling news and reviews', 'infinoax' ),

        'labels'              => $labels,

        // Features this CPT supports in Post Editor

        'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),

        'taxonomies'          => array( 'genres' ),

        /* A hierarchical CPT is like Pages and can have
35
        * Parent and child items. A non-hierarchical CPT
36
        * is like Posts.
37
        */ 

        'hierarchical'        => false,

        'public'              => true,

        'show_ui'             => true,

        'show_in_menu'        => true,

        'show_in_nav_menus'   => true,

        'show_in_admin_bar'   => true,

        'menu_position'       => 5,

        'can_export'          => true,

        'has_archive'         => true,

        'exclude_from_search' => false,

        'publicly_queryable'  => true,

        'capability_type'     => 'page',

    );

    // Registering your Custom Post Type

    register_post_type( 'Kantoorstyling', $args );
}

add_action( 'init', 'custom_post_type_Kantoorstyling', 0 );
///////////////////////////////////

 if ( is_singular( 'product' ) ){
	 
 }
 else{
	 //add_theme_support( 'woocommerce' );
 }

/////////////////////////////////////////////////////////

/* function kia_add_to_cart_validation($passed, $product_id, $qty){
 
    if( isset( $_POST['_custom_option'] ) && sanitize_text_field( $_POST['_custom_option'] ) == '' ){
        $product = wc_get_product( $product_id );
        wc_add_notice( sprintf( __( '%s cannot be added to the cart until you enter some custom text.', 'kia-plugin-textdomain' ), $product->get_title() ), 'error' );
        return false;
    }
 
    return $passed;
 
}
add_filter( 'woocommerce_add_to_cart_validation', 'kia_add_to_cart_validation', 10, 3 ); */



  global $woocommerce;
    if( is_cart() && WC()->cart->cart_contents_count == 0){
		unset($_SESSION['product_session_id']);
    }
/*  
 add_action( 'woocommerce_admin_order_data_after_order_details', 'editable_order_meta_general' );
 
function editable_order_meta_general( $order ){  
   echo $order_id = $_GET['post'];
   echo "test";

		
} */

// display the extra data in the order admin panel
/* 
	$table_name = $wpdb->prefix . 'ribbon';
		$result=$wpdb->get_results( "SELECT * FROM $table_name WHERE product_session_id ='$session_id' AND product_id = '".$product_id."'");
		$count = $wpdb->num_rows;
		if($count != 0){
		  $table_name = $wpdb->prefix . 'ribbon'; */

/* function kia_display_order_data_in_admin( $order ){  ?>
    <div class="order_data_column">
        <h1><?php _e( 'Rouwlint' ); ?></h1>
        <?php 
		global $wpdb;
		$table_name = $wpdb->prefix . 'ribbon';
		$result=$wpdb->get_results( "SELECT * FROM $table_name WHERE order_id = '".$order->id."'");
		$count = $wpdb->num_rows;
		if($count != 0){
            echo '<p><strong>' . __( 'Mourning Ribbon' ) . ':</strong> ' . $result[0]->custom_option . '</p>';
            echo '<p><strong>' . __( 'Mourning ribbon2' ) . ':</strong> ' . $result[0]->custom_option2 . '</p>';
            echo '<p><strong>' . __( 'Message' ) . ':</strong> ' . $result[0]->card_descp . '</p>'; 
		}
		?>
    </div>
<?php }
add_action( 'woocommerce_admin_order_data_after_order_details', 'kia_display_order_data_in_admin' ); */


///// flurnel Extra Charge start
	 function kia_add_cart_checkVal_data( $cart_item, $product_id ){
			
			if( isset( $_POST['checkVal'] ) ) {
				$cart_item['checkVal'] = sanitize_text_field( $_POST['checkVal'] );
			}
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_add_cart_item_data', 'kia_add_cart_checkVal_data', 10, 2 );


		 function kia_get_cart_item_checkVal_session( $cart_item, $values ) {
		 
			if ( isset( $values['checkVal'] ) ){
				$cart_item['checkVal'] = $values['checkVal'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_get_cart_item_from_session', 'kia_get_cart_item_checkVal_session', 20, 2 );

		function kia_add_order_item_checkVal_meta( $item_id, $values ) {
		 
			if ( ! empty( $values['checkVal'] ) ) {
				woocommerce_add_order_item_meta( $item_id, 'checkVal', $values['checkVal'] );           
			}
		}
		add_action( 'woocommerce_add_order_item_meta', 'kia_add_order_item_checkVal_meta', 10, 2 );

/* 		function kia_get_item_checkVal_data( $other_data, $cart_item ) {
		 
			if ( isset( $cart_item['checkVal'] ) ){
		 
				$other_data[] = array(
					'name' => __( 'Extra Charge', 'kia-plugin-textdomain' ),
					'value' => sanitize_text_field( $cart_item['checkVal'] )
				);
		 
			}
		 
			return $other_data;
		 
		}
		add_filter( 'woocommerce_get_item_data', 'kia_get_item_checkVal_data', 10, 2 );

		function kia_order_item_checkVal_product( $cart_item, $order_item ){
		 
			if( isset( $order_item['checkVal'] ) ){
				$cart_item_meta['checkVal'] = $order_item['checkVal'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_item_product', 'kia_order_item_checkVal_product', 10, 2 );

		function kia_email_order_meta_checkVal_fields( $fields ) { 
			$fields['custom_field'] = __( 'Extra Charge', 'kia-plugin-textdomain' ); 
			return $fields; 
		} 
		add_filter('woocommerce_email_order_meta_fields', 'kia_email_order_meta_checkVal_fields');

		function kia_order_again_cart_checkVal_item_data( $cart_item, $order_item, $order ){
		 
			if( isset( $order_item['checkVal'] ) ){
				$cart_item_meta['checkVal'] = $order_item['checkVal'];
			}
		 
			return $cart_item;
		}
		add_filter( 'woocommerce_order_again_cart_item_data', 'kia_order_again_cart_checkVal_item_data', 10, 3 );  */ 
		
///// flurnel Extra Charge products end

///// flurnel products start
		function kia_add_cart_custom_option_data( $cart_item, $product_id ){
			
			if( isset( $_POST['rouwlint1'] ) ) {
				$cart_item['rouwlint1'] = sanitize_text_field( $_POST['rouwlint1'] );
			}
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_add_cart_item_data', 'kia_add_cart_custom_option_data', 10, 2 );


		 function kia_get_cart_item_custom_option_session( $cart_item, $values ) {
		 
			if ( isset( $values['rouwlint1'] ) ){
				$cart_item['rouwlint1'] = $values['rouwlint1'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_get_cart_item_from_session', 'kia_get_cart_item_custom_option_session', 20, 2 );

		function kia_add_order_item_custom_option_meta( $item_id, $values ) {
		 
			if ( ! empty( $values['rouwlint1'] ) ) {
				woocommerce_add_order_item_meta( $item_id, 'rouwlint1', $values['rouwlint1'] );           
			}
		}
		add_action( 'woocommerce_add_order_item_meta', 'kia_add_order_item_custom_option_meta', 10, 2 );

		function kia_get_item_custom_option_data( $other_data, $cart_item ) {
		 
			if ( isset( $cart_item['rouwlint1'] ) ){
		 
				$other_data[] = array(
					'name' => __( 'Rouwlint linker slip', 'kia-plugin-textdomain' ),
					'value' => sanitize_text_field( $cart_item['rouwlint1'] )
				);
		 
			}
		 
			return $other_data;
		 
		}
		add_filter( 'woocommerce_get_item_data', 'kia_get_item_custom_option_data', 10, 2 );

		function kia_order_item_custom_option_product( $cart_item, $order_item ){
		 
			if( isset( $order_item['rouwlint1'] ) ){
				$cart_item_meta['rouwlint1'] = $order_item['rouwlint1'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_item_product', 'kia_order_item_custom_option_product', 10, 2 );

		function kia_email_order_meta_custom_option_fields( $fields ) { 
			$fields['custom_field'] = __( 'Rouwlint linker slip', 'kia-plugin-textdomain' ); 
			return $fields; 
		} 
		add_filter('woocommerce_email_order_meta_fields', 'kia_email_order_meta_custom_option_fields');

		function kia_order_again_cart_custom_option_item_data( $cart_item, $order_item, $order ){
		 
			if( isset( $order_item['rouwlint1'] ) ){
				$cart_item_meta['rouwlint1'] = $order_item['rouwlint1'];
			}
		 
			return $cart_item;
		}
		add_filter( 'woocommerce_order_again_cart_item_data', 'kia_order_again_cart_custom_option_item_data', 10, 3 ); 
		
///// flurnel csutom product 1 products end

///// flurnel custom_option2 products start
		function kia_add_cart_custom_option2_data( $cart_item, $product_id ){
			
			if( isset( $_POST['rouwlint2'] ) ) {
				$cart_item['rouwlint2'] = sanitize_text_field( $_POST['rouwlint2'] );
			}
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_add_cart_item_data', 'kia_add_cart_custom_option2_data', 10, 2 );


		 function kia_get_cart_item_custom_option2_session( $cart_item, $values ) {
		 
			if ( isset( $values['rouwlint2'] ) ){
				$cart_item['rouwlint2'] = $values['rouwlint2'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_get_cart_item_from_session', 'kia_get_cart_item_custom_option2_session', 20, 2 );

		function kia_add_order_item_custom_option2_meta( $item_id, $values ) {
		 
			if ( ! empty( $values['rouwlint2'] ) ) {
				woocommerce_add_order_item_meta( $item_id, 'rouwlint2', $values['rouwlint2'] );           
			}
		}
		add_action( 'woocommerce_add_order_item_meta', 'kia_add_order_item_custom_option2_meta', 10, 2 );

		function kia_get_item_custom_option2_data( $other_data, $cart_item ) {
		 
			if ( isset( $cart_item['rouwlint2'] ) ){
		 
				$other_data[] = array(
					'name' => __( 'Rouwlint linker slip2', 'kia-plugin-textdomain' ),
					'value' => sanitize_text_field( $cart_item['rouwlint2'] )
				);
			}
			return $other_data;
		 
		}
		add_filter( 'woocommerce_get_item_data', 'kia_get_item_custom_option2_data', 10, 2 );

		function kia_order_item_custom_option2_product( $cart_item, $order_item ){
		 
			if( isset( $order_item['rouwlint2'] ) ){
				$cart_item_meta['rouwlint2'] = $order_item['rouwlint2'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_item_product', 'kia_order_item_custom_option2_product', 10, 2 );

		function kia_email_order_meta_custom_option2_fields( $fields ) { 
			$fields['custom_field'] = __( 'Rouwlint linker slip2', 'kia-plugin-textdomain' ); 
			return $fields; 
		} 
		add_filter('woocommerce_email_order_meta_fields', 'kia_email_order_meta_custom_option2_fields');

		function kia_order_again_cart_custom_option2_item_data( $cart_item, $order_item, $order ){
		 
			if( isset( $order_item['rouwlint2'] ) ){
				$cart_item_meta['rouwlint2'] = $order_item['rouwlint2'];
			}
		 
			return $cart_item;
		}
		add_filter( 'woocommerce_order_again_cart_item_data', 'kia_order_again_cart_custom_option2_item_data', 10, 3 ); 
		
///// flurnel custom_option2 products end

///// flurnel boodschap products start
		function kia_add_cart_card_descp_data( $cart_item, $product_id ){
			
			if( isset( $_POST['boodschap'] ) ) {
				$cart_item['boodschap'] = sanitize_text_field( $_POST['boodschap'] );
			}
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_add_cart_item_data', 'kia_add_cart_card_descp_data', 10, 2 );


		 function kia_get_cart_item_card_descp_session( $cart_item, $values ) {
		 
			if ( isset( $values['boodschap'] ) ){
				$cart_item['boodschap'] = $values['boodschap'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_get_cart_item_from_session', 'kia_get_cart_item_card_descp_session', 20, 2 );

		function kia_add_order_item_card_descp_meta( $item_id, $values ) {
		 
			if ( ! empty( $values['boodschap'] ) ) {
				woocommerce_add_order_item_meta( $item_id, 'boodschap', $values['boodschap'] );           
			}
		}
		add_action( 'woocommerce_add_order_item_meta', 'kia_add_order_item_card_descp_meta', 10, 2 );

		function kia_get_item_card_descp_data( $other_data, $cart_item ) {
		 
			if ( isset( $cart_item['boodschap'] ) ){
		 
				$other_data[] = array(
					'name' => __( 'Boodschap', 'kia-plugin-textdomain' ),
					'value' => sanitize_text_field( $cart_item['boodschap'] )
				);
			}
			return $other_data;
		 
		}
		add_filter( 'woocommerce_get_item_data', 'kia_get_item_card_descp_data', 10, 2 );

		function kia_order_item_card_descp_product( $cart_item, $order_item ){
		 
			if( isset( $order_item['boodschap'] ) ){
				$cart_item_meta['boodschap'] = $order_item['boodschap'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_item_product', 'kia_order_item_card_descp_product', 10, 2 );

		function kia_email_order_meta_card_descp_fields( $fields ) { 
			$fields['custom_field'] = __( 'Boodschap', 'kia-plugin-textdomain' ); 
			return $fields; 
		} 
		add_filter('woocommerce_email_order_meta_fields', 'kia_email_order_meta_card_descp_fields');

		function kia_order_again_cart_card_descp_item_data( $cart_item, $order_item, $order ){
		 
			if( isset( $order_item['boodschap'] ) ){
				$cart_item_meta['boodschap'] = $order_item['boodschap'];
			}
		 
			return $cart_item;
		}
		add_filter( 'woocommerce_order_again_cart_item_data', 'kia_order_again_cart_card_descp_item_data', 10, 3 ); 
///// flurnel card_descp products end	
		
///quick order booketcount

		function kia_add_cart_single_data( $cart_item, $product_id ){
			
			if( isset( $_POST['boeketCount'] ) ) {
				$cart_item['boeketCount'] = sanitize_text_field( $_POST['boeketCount'] );
			}
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_add_cart_item_data', 'kia_add_cart_single_data', 10, 2 );


		 function kia_get_cart_item_single_session( $cart_item, $values ) {
		 
			if ( isset( $values['boeketCount'] ) ){
				$cart_item['boeketCount'] = $values['boeketCount'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_get_cart_item_from_session', 'kia_get_cart_item_single_session', 20, 2 );

		function kia_add_order_item_single_meta( $item_id, $values ) {
		 
			if ( ! empty( $values['boeketCount'] ) ) {
				woocommerce_add_order_item_meta( $item_id, 'boeketCount', $values['boeketCount'] );           
			}
		}
		add_action( 'woocommerce_add_order_item_meta', 'kia_add_order_item_single_meta', 10, 2 );

		function kia_get_item_single_data( $other_data, $cart_item ) {
		 
			if ( isset( $cart_item['boeketCount'] ) ){
		 
				$other_data[] = array(
					'name' => __( 'Boeket', 'kia-plugin-textdomain' ),
					'value' => sanitize_text_field( $cart_item['boeketCount'] )
				);
		 
			}
		 
			return $other_data;
		 
		}
		add_filter( 'woocommerce_get_item_data', 'kia_get_item_single_data', 10, 2 );

		function kia_order_item_single_product( $cart_item, $order_item ){
		 
			if( isset( $order_item['boeketCount'] ) ){
				$cart_item_meta['boeketCount'] = $order_item['boeketCount'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_item_product', 'kia_order_item_single_product', 10, 2 );

		function kia_email_order_meta_single_fields( $fields ) { 
			$fields['custom_field'] = __( 'Boeket', 'kia-plugin-textdomain' ); 
			return $fields; 
		} 
		add_filter('woocommerce_email_order_meta_fields', 'kia_email_order_meta_single_fields');

		function kia_order_again_cart__single_item_data( $cart_item, $order_item, $order ){
		 
			if( isset( $order_item['boeketCount'] ) ){
				$cart_item_meta['boeketCount'] = $order_item['boeketCount'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_again_cart_item_data', 'kia_order_again_cart__single_item_data', 10, 3 ); 
		
//checkbox product card	
		
function kia_add_cart_single_checkboxBooket( $cart_item, $product_id ){
			
			if( isset( $_POST['checkboxBooket'] ) ) {
				$cart_item['checkboxBooket'] = sanitize_text_field( $_POST['checkboxBooket'] );
			}
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_add_cart_item_data', 'kia_add_cart_single_checkboxBooket', 10, 2 );


		 function kia_get_cart_item_checkboxBooket_session( $cart_item, $values ) {
		 
			if ( isset( $values['checkboxBooket'] ) ){
				$cart_item['checkboxBooket'] = $values['checkboxBooket'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_get_cart_item_from_session', 'kia_get_cart_item_checkboxBooket_session', 20, 2 );

		function kia_add_order_item_checkboxBooket_meta( $item_id, $values ) {
		 
			if ( ! empty( $values['checkboxBooket'] ) ) {
				woocommerce_add_order_item_meta( $item_id, 'checkboxBooket', $values['checkboxBooket'] );           
			}
		}
		add_action( 'woocommerce_add_order_item_meta', 'kia_add_order_item_checkboxBooket_meta', 10, 2 );

		function kia_get_item_checkboxBooket_data( $other_data, $cart_item ) {
		 
			if ( isset( $cart_item['checkboxBooket'] ) ){
		 
				$other_data[] = array(
					'name' => __( 'Vaas', 'kia-plugin-textdomain' ),
					'value' => sanitize_text_field( $cart_item['checkboxBooket'] )
				);
		 
			}
		 
			return $other_data;
		 
		}
		add_filter( 'woocommerce_get_item_data', 'kia_get_item_checkboxBooket_data', 10, 2 );

		function kia_order_item_checkboxBooket_product( $cart_item, $order_item ){
		 
			if( isset( $order_item['checkboxBooket'] ) ){
				$cart_item_meta['checkboxBooket'] = $order_item['checkboxBooket'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_item_product', 'kia_order_item_checkboxBooket_product', 10, 2 );

		function kia_email_order_meta_checkboxBooket_fields( $fields ) { 
			$fields['checkboxBooket'] = __( 'Vaas', 'kia-plugin-textdomain' ); 
			return $fields; 
		} 
		add_filter('woocommerce_email_order_meta_fields', 'kia_email_order_meta_checkboxBooket_fields');

		function kia_order_again_cart__checkboxBooket_item_data( $cart_item, $order_item, $order ){
		 
			if( isset( $order_item['checkboxBooket'] ) ){
				$cart_item_meta['checkboxBooket'] = $order_item['checkboxBooket'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_again_cart_item_data', 'kia_order_again_cart__checkboxBooket_item_data', 10, 3 ); 
		
		////product card end
		
//Number product card start	
		
function kia_add_cart_single_numberCard( $cart_item, $product_id ){
			
			if( isset( $_POST['numberCard'] ) ) {
				$cart_item['numberCard'] = sanitize_text_field( $_POST['numberCard'] );
			}
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_add_cart_item_data', 'kia_add_cart_single_numberCard', 10, 2 );


		 function kia_get_cart_item_numberCard_session( $cart_item, $values ) {
		 
			if ( isset( $values['numberCard'] ) ){
				$cart_item['numberCard'] = $values['numberCard'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_get_cart_item_from_session', 'kia_get_cart_item_numberCard_session', 20, 2 );

		function kia_add_order_item_numberCard_meta( $item_id, $values ) {
		 
			if ( ! empty( $values['numberCard'] ) ) {
				woocommerce_add_order_item_meta( $item_id, 'numberCard', $values['numberCard'] );           
			}
		}
		add_action( 'woocommerce_add_order_item_meta', 'kia_add_order_item_numberCard_meta', 10, 2 );

		function kia_get_item_numberCard_data( $other_data, $cart_item ) {
		 
			if ( isset( $cart_item['numberCard'] ) ){
		 
				$other_data[] = array(
					'name' => __( 'numberCard', 'kia-plugin-textdomain' ),
					'value' => sanitize_text_field( $cart_item['numberCard'] )
				);
		 
			}
		 
			return $other_data;
		 
		}
		add_filter( 'woocommerce_get_item_data', 'kia_get_item_numberCard_data', 10, 2 );

		function kia_order_item_numberCard_product( $cart_item, $order_item ){
		 
			if( isset( $order_item['numberCard'] ) ){
				$cart_item_meta['numberCard'] = $order_item['numberCard'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_item_product', 'kia_order_item_numberCard_product', 10, 2 );

		function kia_email_order_meta_numberCard_fields( $fields ) { 
			$fields['numberCard'] = __( 'NumberCard', 'kia-plugin-textdomain' ); 
			return $fields; 
		} 
		add_filter('woocommerce_email_order_meta_fields', 'kia_email_order_meta_numberCard_fields');

		function kia_order_again_cart__numberCard_item_data( $cart_item, $order_item, $order ){
		 
			if( isset( $order_item['numberCard'] ) ){
				$cart_item_meta['numberCard'] = $order_item['numberCard'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_again_cart_item_data', 'kia_order_again_cart__numberCard_item_data', 10, 3 ); 
		
		////product NumberCard end
				
//textarea product card start	
		
function kia_add_cart_single_cardWords( $cart_item, $product_id ){
			
			if( isset( $_POST['cardWords'] ) ) {
				$cart_item['cardWords'] = sanitize_text_field( $_POST['cardWords'] );
			}
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_add_cart_item_data', 'kia_add_cart_single_cardWords', 10, 2 );


		 function kia_get_cart_item_cardWords_session( $cart_item, $values ) {
		 
			if ( isset( $values['cardWords'] ) ){
				$cart_item['cardWords'] = $values['cardWords'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_get_cart_item_from_session', 'kia_get_cart_item_cardWords_session', 20, 2 );

		function kia_add_order_item_cardWords_meta( $item_id, $values ) {
		
			if ( ! empty( $values['cardWords'] ) ) {
				woocommerce_add_order_item_meta( $item_id, 'cardWords', $values['cardWords'] );           
			}
		}
		add_action( 'woocommerce_add_order_item_meta', 'kia_add_order_item_cardWords_meta', 10, 2 );

		function kia_get_item_cardWords_data( $other_data, $cart_item ) {
		 
			if ( isset( $cart_item['cardWords'] ) ){
			 if(!empty($cart_item['cardWords'])){
					$other_data[] = array(
						'name' => __( 'Words', 'kia-plugin-textdomain' ),
						'value' => sanitize_text_field( $cart_item['cardWords'] )
					);
			 
				}
			}
		 
			return $other_data;
		 
		}
		add_filter( 'woocommerce_get_item_data', 'kia_get_item_cardWords_data', 10, 2 );

		function kia_order_item_cardWords_product( $cart_item, $order_item ){
		 
			if( isset( $order_item['cardWords'] ) ){
				$cart_item_meta['cardWords'] = $order_item['cardWords'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_item_product', 'kia_order_item_cardWords_product', 10, 2 );

		function kia_email_order_meta_cardWords_fields( $fields ) { 
			$fields['cardWords'] = __( 'Words', 'kia-plugin-textdomain' ); 
			return $fields; 
		} 
		add_filter('woocommerce_email_order_meta_fields', 'kia_email_order_meta_cardWords_fields');

		function kia_order_again_cart_cardWords_item_data( $cart_item, $order_item, $order ){
		 
			if( isset( $order_item['cardWords'] ) ){
				$cart_item_meta['cardWords'] = $order_item['cardWords'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_again_cart_item_data', 'kia_order_again_cart_cardWords_item_data', 10, 3 ); 
		
		////textarea card end

//// prefer start	
		
function kia_add_cart_single_prefer( $cart_item, $product_id ){
			
			if( isset( $_POST['prefer'] ) ) {
				$cart_item['prefer'] = sanitize_text_field( $_POST['prefer'] );
			}
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_add_cart_item_data', 'kia_add_cart_single_prefer', 10, 2 );


		 function kia_get_cart_item_prefer_session( $cart_item, $values ) {
		 
			if ( isset( $values['prefer'] ) ){
				$cart_item['prefer'] = $values['prefer'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_get_cart_item_from_session', 'kia_get_cart_item_prefer_session', 20, 2 );

		function kia_add_order_item_prefer_meta( $item_id, $values ) {
		 
			if ( ! empty( $values['prefer'] ) ) {
				woocommerce_add_order_item_meta( $item_id, 'prefer', $values['prefer'] );           
			}
		}
		add_action( 'woocommerce_add_order_item_meta', 'kia_add_order_item_prefer_meta', 10, 2 );

		function kia_get_item_prefer_data( $other_data, $cart_item ) {
		 
			if ( isset( $cart_item['prefer'] ) ){
		 
				$other_data[] = array(
					'name' => __( 'prefer', 'kia-plugin-textdomain' ),
					'value' => sanitize_text_field( $cart_item['prefer'] )
				);
		 
			}
			return $other_data;
		 
		}
		add_filter( 'woocommerce_get_item_data', 'kia_get_item_prefer_data', 10, 2 );

		function kia_order_item_prefer_product( $cart_item, $order_item ){
		 
			if( isset( $order_item['prefer'] ) ){
				$cart_item_meta['prefer'] = $order_item['prefer'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_item_product', 'kia_order_item_prefer_product', 10, 2 );

		function kia_email_order_meta_prefer_fields( $fields ) { 
			$fields['prefer'] = __( 'prefer', 'kia-plugin-textdomain' ); 
			return $fields; 
		} 
		add_filter('woocommerce_email_order_meta_fields', 'kia_email_order_meta_prefer_fields');

		function kia_order_again_cart__prefer_item_data( $cart_item, $order_item, $order ){
		 
			if( isset( $order_item['prefer'] ) ){
				$cart_item_meta['prefer'] = $order_item['prefer'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_again_cart_item_data', 'kia_order_again_cart__prefer_item_data', 10, 3 ); 
		
		////product prefer end		
////COLOR START	
		
function kia_add_cart_single_color( $cart_item, $product_id ){
	
	if( isset( $_POST['color'] ) ) {
		$cart_item['color'] = sanitize_text_field( $_POST['color'] );
	}
	return $cart_item;
 
}
add_filter( 'woocommerce_add_cart_item_data', 'kia_add_cart_single_color', 10, 2 );


 function kia_get_cart_item_color_session( $cart_item, $values ) {
 
	if ( isset( $values['color'] ) ){
		$cart_item['color'] = $values['color'];
	}
 
	return $cart_item;
 
}
add_filter( 'woocommerce_get_cart_item_from_session', 'kia_get_cart_item_color_session', 20, 2 );

function kia_add_order_item_color_meta( $item_id, $values ) {

	if ( ! empty( $values['color'] ) ) {
		woocommerce_add_order_item_meta( $item_id, 'color', $values['color'] );           
	}
}
add_action( 'woocommerce_add_order_item_meta', 'kia_add_order_item_color_meta', 10, 2 );

function kia_get_item_color_data( $other_data, $cart_item ) {
 
	if ( isset( $cart_item['color'] ) ){
	 if(!empty($cart_item['color'])){
			$other_data[] = array(
				'name' => __( 'Color', 'kia-plugin-textdomain' ),
				'value' => sanitize_text_field( $cart_item['color'] )
			);
	 
		}
	}
 
	return $other_data;
 
}
add_filter( 'woocommerce_get_item_data', 'kia_get_item_color_data', 10, 2 );

function kia_order_item_color_product( $cart_item, $order_item ){
 
	if( isset( $order_item['color'] ) ){
		$cart_item_meta['color'] = $order_item['color'];
	}
 
	return $cart_item;
 
}
add_filter( 'woocommerce_order_item_product', 'kia_order_item_color_product', 10, 2 );

function kia_email_order_meta_color_fields( $fields ) { 
	$fields['color'] = __( 'Color', 'kia-plugin-textdomain' ); 
	return $fields; 
} 
add_filter('woocommerce_email_order_meta_fields', 'kia_email_order_meta_color_fields');

function kia_order_again_cart_color_item_data( $cart_item, $order_item, $order ){
 
	if( isset( $order_item['color'] ) ){
		$cart_item_meta['color'] = $order_item['color'];
	}
 
	return $cart_item;
 
}
add_filter( 'woocommerce_order_again_cart_item_data', 'kia_order_again_cart_color_item_data', 10, 3 ); 

////COLOR END	
session_start(); 
$session_id =$_SESSION["product_session_id"];
// changing price at add to cart
 add_action( 'woocommerce_before_calculate_totals', 'add_custom_price' );
function add_custom_price( $cart_object ) {
	 global $wpdb;
	
	 $session_id =$_SESSION["product_session_id"];
	$funeralProduct = array();
	 $table_name = $wpdb->prefix . 'ribbon';
	$result=$wpdb->get_results( "SELECT * FROM $table_name WHERE product_session_id ='$session_id'");
/* 	echo "<pre>";
	print_r($result); */

	foreach ( $result as $print ){
	  $funeralProduct[] = $print->product_id;
	}
/* 	echo "<pre>";
 print_r($funeralProduct);
die; */
	 $removeSession= array();
		foreach ( $cart_object->cart_contents as $key => $value ) {
		/* 	echo "<pre>";
			print_r($value); */
 
        //echo $item->get_name();
		 $removeSession[] = $value['product_id'];
		  $checkVal = $value['checkVal'];
		 $cart_product_id = $value['product_id'];
		$quantiy = $value['quantity'];
	  $variation = $value['variation']['attribute_select-size'];
/* echo $checkVal;
echo "<br>"; */
		if ($checkVal != 0){
				 if (strpos($variation, '25') !== false) {
						$product = wc_get_product( $cart_product_id );
						$cart_price = 25;
						$extra_price = 17.50;
						$final_price = $cart_price + $extra_price;	
						$value['data']->set_price($final_price);
				}elseif(strpos($variation, '50') !== false){
									$product = wc_get_product( $cart_product_id );
						 $cart_price = 50;
						$extra_price = 17.50;
						 $final_price = $cart_price + $extra_price;	
						$value['data']->set_price($final_price);
									
					}elseif(strpos($variation, '70') !== false){
									$product = wc_get_product( $cart_product_id );
						 $cart_price = 70;
						$extra_price = 17.50;
						 $final_price = $cart_price + $extra_price;	
						$value['data']->set_price($final_price);
						
				}else{
			 $product = wc_get_product( $cart_product_id );
			/*  echo "<pre>";
			 print_r($product); */
			 $cart_price = $product->get_price();
			$extra_price = 17.50;
			 $final_price = $cart_price + $extra_price;	
			$value['data']->set_price($final_price);
					}
		}else{
			 if (strpos($variation, '30') !== false) {
						$product = wc_get_product( $cart_product_id );
						 $cart_price = 30;
						$extra_price = 17.50;
						 $final_price = $cart_price;	
						$value['data']->set_price($final_price);
				}elseif(strpos($variation, '50') !== false){
									$product = wc_get_product( $cart_product_id );
						 $cart_price = 50;
						$extra_price = 17.50;
						 $final_price = $cart_price;	
						$value['data']->set_price($final_price);
									
					}elseif(strpos($variation, '70') !== false){
									$product = wc_get_product( $cart_product_id );
						 $cart_price = 70;
						$extra_price = 17.50;
						 $final_price = $cart_price;	
						$value['data']->set_price($final_price);
						
				}
		}
		
	}
/* $result=$wpdb->get_results( "SELECT * FROM $table_name WHERE product_session_id ='$session_id'");

 $session_product_id = $result[0]->product_id;
	if (in_array($session_product_id, $removeSession)){}
    else{
		$results=$wpdb->get_results( "DELETE FROM $table_name WHERE product_session_id ='$session_id'");
		   unset($_SESSION['product_session_id']);
	} */
	
}

function custom_registration_redirect() {
    wp_logout();
    return home_url('/static/wp-bbb/bestellen/');
}
add_action('woocommerce_registration_redirect', 'custom_registration_redirect', 2);