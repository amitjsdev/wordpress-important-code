<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); 

 if ( is_singular( 'product' ) ) {
    // conditional content/code
	?>
	        <section class="page-title-block snglePrduct">
          <div class="container">
            <h1><?php the_title();?></h1>
          </div>
		  <?php  do_action( 'woocommerce_before_single_product' );?>
        </section>
		
			<?php
	
		// Start the loop.
		while ( have_posts() ) : the_post();

			// Include the single post content template.
			get_template_part( 'template-parts/content', 'single' );
		endwhile; 
		?>
	 
<?php
/* echo $id = $product->get_id();
$terms = get_the_terms ( $id, 'product_cat' );
echo "<pre>";
print_r($terms);
foreach ( $terms as $term ) {
   echo $cat_id = $term->id;
} */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $product, $woocommerce_loop;

if ( empty( $product ) || ! $product->exists() ) {
    return;
}

if ( ! $related = $product->get_related( $posts_per_page ) ) {
    return;
}

$cats_array = array(0);

// get categories
$terms = wp_get_post_terms( $product->id, 'product_cat' );

// select only the category which doesn't have any children
foreach ( $terms as $term ) {
    $children = get_term_children( $term->term_id, 'product_cat' );
    if ( !sizeof( $children ) )
    $cats_array[] = $term->term_id;
}



$args = apply_filters( 'woocommerce_related_products_args', array(
    'exclude' => array( $product->get_id()),
    'post_type' => 'product',
    'ignore_sticky_posts' => 1,
    'post__not_in' => array( $product->get_id() ),
    'no_found_rows' => 1,
    'posts_per_page' => $posts_per_page,
    'orderby' => $orderby,
    'tax_query' => array(
        array(
            'taxonomy' => 'product_cat',
            'field' => 'id',
            'terms' => $cats_array
        ),
    )
));

$products                    = new WP_Query( $args );
$woocommerce_loop['name']    = 'related';
$woocommerce_loop['columns'] = apply_filters( 'woocommerce_related_products_columns', $columns );

if ( $products->have_posts() ) : ?>

   <section class="our-flowers">
          <div class="container">
            <div class="head-border-main" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100">
              <h2>Gerelateerde producten</h2>
            </div>
            <div class="our-flowers-block">
              <div class="row">

        <?php 
		
		$c=0;
		 ?>

            <?php while ( $products->have_posts() ) : $products->the_post();
					$_product = wc_get_product( $product->get_id());
				if($c < 4){	

					?>
                <div class="col-sm-3" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100">
                  <div class="our-flowers-box">
                    <figure>
					<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $product->get_id() ), 'single-post-thumbnail' );
					/* echo "<pre>";
					print_r($image); */?>
                      <a href="<?php echo get_permalink( $product->get_id() );?>">
                        <img src="<?php echo $image[0];?>">
                      </a>
                    </figure>
                    <figcaption>
					
                      <h3 class="name-flower"><a href="<?php echo get_permalink( $product->get_id() );?>"><?php echo get_the_title();?></a></h3>
                      <span class="price-flower">€ <?php echo $_product->get_price();?></span>
                      <a href="<?php echo get_permalink( $product->get_id() );?>" class="btn-cart">	
						<img src="<?php echo get_template_directory_uri();?>/images/cart-icon.png" alt=""><span>Bestellen</span></a>
                    </figcaption>
                  </div>
                </div>

            <?php
				
				}
					$c++;
			endwhile; // end of the loop. ?>


				</div>
			</div>
		</div>
	</section>

<?php endif;

wp_reset_postdata();


 } else {
	 ?>

<div id="primary" class="content-area proo">
	<main id="main" class="site-main" role="main">
		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();

			// Include the single post content template.
			get_template_part( 'template-parts/content', 'single' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}

			if ( is_singular( 'attachment' ) ) {
				// Parent post navigation.
				the_post_navigation( array(
					'prev_text' => _x( '<span class="meta-nav">Published in</span><span class="post-title">%title</span>', 'Parent post link', 'twentysixteen' ),
				) );
			} elseif ( is_singular( 'post' ) ) {
				// Previous/next post navigation.
				the_post_navigation( array(
					'next_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Next', 'twentysixteen' ) . '</span> ' .
						'<span class="screen-reader-text">' . __( 'Next post:', 'twentysixteen' ) . '</span> ' .
						'<span class="post-title">%title</span>',
					'prev_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Previous', 'twentysixteen' ) . '</span> ' .
						'<span class="screen-reader-text">' . __( 'Previous post:', 'twentysixteen' ) . '</span> ' .
						'<span class="post-title">%title</span>',
				) );
			}

			// End of the loop.
		endwhile;
		?>

	</main><!-- .site-main -->

	<?php get_sidebar( 'content-bottom' ); ?>

</div><!-- .content-area -->


<?php
 }
 ?>
<?php get_footer(); ?>
