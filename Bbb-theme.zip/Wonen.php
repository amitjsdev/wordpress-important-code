<?php
/**
 * Template name: Wonen
 */

get_header(); ?>


	<section class="page-title-block about-us-title flower-head-block" data-aos="fade-in" data-aos-duration="600" data-aos-delay="100ms">
          <div class="container">
            <h1><?php the_title();?></h1>
            <p><?php echo get_post_meta($post->ID, 'Wonen Content', true);?></p>
          </div>
        </section>
		<?php 
				while ( have_posts() ) : the_post();
				?>
        <section class="home-acceries flower-feature-block">
          <div class="container">
            <div class="row">
              <div class="col-sm-6 align-self-center content-acceries-left" data-aos="fade-right" data-aos-duration="600" data-aos-delay="370ms">
	<?php the_content();?>
              </div>
              <div class="col-sm-6 align-self-center" data-aos="fade-left" data-aos-duration="600" data-aos-delay="370ms">
                <div class="acceriest-img">
                  <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="" />
                </div>
              </div>
            </div>
          </div>
        </section>
		<?php
			endwhile;  
			wp_reset_query();
		?>
        <section class="about-gallery-img" data-aos="fade-up" data-aos-duration="600" data-aos-delay="370ms">
          <div class="container">
            <div class="row">
			      <?php 
					$all_images = MIU_GET_IMAGES();
					foreach($all_images as $val_images){
						?>
						  <div class="col-md-3 col-sm-6">
							<a href="javascript:void(0);">
							  <img src="<?Php echo $val_images;?>" alt="" />
							</a>
						  </div>
						<?php
					} 
					?>
            </div>
          </div>
        </section>
        <section class="flower-about-content">
          <div class="container">
            <div class="block-text-about" data-aos="fade-in" data-aos-duration="600" data-aos-delay="370ms">
              <h3><?php echo get_post_meta($post->ID, 'Wonen Service Title', true);?></h3>
              <p><?php echo get_post_meta($post->ID, 'Wonen Service Content', true);?></p>
            </div>
          </div>
        </section>
        
        <section class="order-timing business-contact" style="background-image: url(<?php echo get_template_directory_uri();?>/images/bussiness.png);">
          <div class="container">
			<?php dynamic_sidebar('sidebar-8');?>
          </div>
        </section>
        <section class="all-funeral-feature">
          <div class="container">  
            <h2 data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><?php echo get_post_meta($post->ID, 'Wonen Testimonial', true);?></h2>
            <div class="row" data-aos="fade-up" data-aos-duration="600" data-aos-delay="370ms">
			    <?php
				$args = array( 'post_type' => 'Wonen', 'order' => 'ASC');
				$loop = new WP_Query( $args );
				while ( $loop->have_posts() ) : $loop->the_post();
				?>
				  
              <div class="col-sm-3">
                <a href="javascript:void(0);" class="img-funeral">
                  <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="" />
                  <span><?php the_title();?></span>
                </a>
              </div>
			  	  <?php
				endwhile;
				?>
            </div>
          </div>
        </section>

		
<?php get_footer(); ?>
