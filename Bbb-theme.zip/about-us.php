<?php
/**
 * Template name: about-us
 */

get_header(); ?>
 	<?php 
				while ( have_posts() ) : the_post();
				the_content();
				endwhile;  
				wp_reset_query(); ?>
 <section class="quick-delivery-block" style="background-image: url(<?php echo get_template_directory_uri();?>/images/flower-quick-bg.png);">
          <div class="container">
		  <?php dynamic_sidebar('sidebar-13');?>
          </div>
        </section>
        <section class="easy-access-block" data-aos="fade-in" data-aos-duration="600" data-aos-delay="200ms">
          <div class="container">
            <h3><?php echo get_post_meta($post->ID, 'Easily accessible title', true);?></h3>
            <p><?php echo get_post_meta($post->ID, 'Easily accessible content', true);?></p>
          </div>
        </section>
 
        <section class="brand-block" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="100ms">
          <div class="container">
            <h3><?php echo get_post_meta($post->ID, 'Brands title', true);?></h3>
            <p><?php echo get_post_meta($post->ID, 'Brands content', true);?></p>
            <div class="list-brand str_wrap str3">
        <?php 
		$all_images = MIU_GET_IMAGES();
		foreach($all_images as $val_images){
			?>
			<img src="<?Php echo $val_images;?>" alt="" />
			<?php
		} 
		?>
            </div>
          </div>
        </section>
<?php get_footer(); ?>
