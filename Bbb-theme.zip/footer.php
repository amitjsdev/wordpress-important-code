<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>
 <section class="user-about" data-aos="fade-left" data-aos-duration="600" data-aos-delay="100">
          <div class="container">
<h5>De aarde lacht in bloemen.</h5>
<div class="dash-line"></div>
<span>Ralph Waldo Emerson</span>
          </div>
        </section>
        <footer class="footer-main">
          <img src="<?php echo get_template_directory_uri();?>/images/img-footer.png" class="bg-img-footer">
          <div class="container">
            <div class="row">
              <div class="col-sm-4">
                <div class="footer-block-1 footerFirst">
<?php dynamic_sidebar('sidebar-4');?>

                </div>
              </div>
              <div class="col-sm-4">
                <div class="footer-nav footerNav">
<?php dynamic_sidebar('sidebar-5');?>
                </div>
              </div>
              <div class="col-sm-4">
                <div class="open-timing">
<?php dynamic_sidebar('sidebar-6');?>
                </div>
              </div>
            </div>
            <div class="copyright-block">
			<?php dynamic_sidebar('sidebar-7');?>
             <div class="design-by">Webdesign: <a href="https://www.142design.nl/" target="_blank" >142Design.nl</a></div>
            </div>
          </div>
        </footer>
      </div>
	  <?php wp_footer(); ?>
	 
   </body>
  
      <script type="text/javascript" src="https://unpkg.com/popper.js@1.14.4/dist/umd/popper.min.js"></script>
   <script type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/bootstrap.min.js"></script>
   <script type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/bootstrap-select.min.js"></script>
   <script src="<?php echo get_template_directory_uri();?>/js/jquery.liMarquee.js"></script>
   <script type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/aos.js"></script>
   <script type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/custom.js"></script>
      
 
   <script>
   $('.resetButton').click( function(e){
	window.location = window.location.pathname;
	//  alert(shopurl);
	   		 //location.reload();
   });

$('.filterCatagories').click( function(e){
	$('.loader').css('display','block');
	$('.product-listing').css('opacity','.5'); 
	$('.load-more').attr('data-offset', 9);
	var price_val = $('.price_val').val();
	var orderby_val = $('.orderby_val').val();
	var arr_cat =[];
	var postOffset="";
	var PerPage = 9;				
	var cat_id = $("input:checkbox[name=filterCheckbox]:checked").attr("id");
	if(cat_id == "all"){
		 location.reload();
	}
	if(typeof (cat_id) == "undefined"){
		 location.reload();
	}
	var fields = $("input:checkbox[name=filterCheckbox]:checked").serializeArray(); 
	//alert(fields.length);
	var counter = 0;
	var ajaxurl = 'http://infinoax.com/static/wp-bbb/ajax-product/';
		 if(fields.length == 1){
			 var cat_id = $("input:checkbox[name=filterCheckbox]:checked").attr("id");
			function countprodcuts(){
				var postOffsetcount="";
				var PerPagecount=-1;
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {post_offset: postOffsetcount,posts_per_page: PerPagecount,product_cat:cat_id,pricepara:price_val,orderby:orderby_val},
						cache: false,
						success: function (data) {
							$('.loader').css('display','none');
							$('.product-listing').css("opacity","1"); 
							var arr = $.parseJSON(data); 
							$.each(arr,function(key,value){
								counter++;
							});
							//alert(counter);
							//alert(counter);
							var newcounter =parseInt(counter) - parseInt(9);
							if(newcounter < 1){
								$('.loadMoreCount').css('display', 'none');
							}else{
								$('.loadMoreCount').text("Laad meer producten ("+newcounter+")");
								$('.loadMoreCount').css('display', 'inline-block');
							}
							if(counter == 0){
								$('.product_id').append('<div class="load-more-product aos-init aos-animate nofound" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><a href="javascript:void(0);" class=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Geen product gevonden ...!</font></font></a></div>');
							}
						
						}
						
					});	
			}
			var noproduct = 0;
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {
								post_offset: postOffset,
								posts_per_page: PerPage,
								product_cat: cat_id,
								pricepara:price_val,
								orderby:orderby_val
						},
						cache: false,
						success: function (data) {
							countprodcuts();
							var arr = $.parseJSON(data); 
							$(".product_id").empty();
							$.each(arr,function(key,value){
								var get_id= value.get_id;
								var image= value.image;
								var get_price= value.get_price;
								var get_permalink= value.get_permalink;
								var get_the_content= value.get_the_content;
								var get_permalink= value.get_permalink;
								var get_the_title= value.get_the_title;
								
								$('.product_id').append('<div class="col-sm-4"><a href="'+get_permalink+'" class="list-product-ui aos-init aos-animate" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><figure><img src="'+image+'" data-id="'+get_id+'"></figure><div class="figure-content"><div class="price-value"><label>Vanaf</label><span><?php echo get_woocommerce_currency_symbol();?>  '+get_price+'</span></div><div class="name-flower">'+get_the_title+'</div></div></a></div>');
						noproduct++;
							}); 
						},
						error: function () {
						}
					});	
		 }else{
			$("input:checkbox[name=filterCheckbox]:checked").each(function(index){
				arr_cat.push($(this).attr("id"));
			}); 
			var counter_arr =0;
		function countprodcuts_arr(){
				var postOffsetcount="";
				var PerPagecount=-1;
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {post_offset: postOffsetcount,posts_per_page: PerPagecount,product_cat_arr: arr_cat,pricepara:price_val,orderby:orderby_val},
						cache: false,
						success: function (data) {
							$('.loader').css('display','none');
							$('.product-listing').css("opacity","1"); 
							var arr = $.parseJSON(data); 
							$.each(arr,function(key,value){
								counter_arr++;
							});
							//alert(counter_arr);
							var newcounter =parseInt(counter_arr) - parseInt(9);
							if(newcounter < 1){
								$('.loadMoreCount').css('display', 'none');
							}else{
								$('.loadMoreCount').text("Laad meer producten ("+newcounter+")");
								$('.loadMoreCount').css('display', 'inline-block');
							}
						if(counter_arr == 0){
								$('.product_id').append('<div class="load-more-product aos-init aos-animate nofound" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><a href="javascript:void(0);" class=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Geen product gevonden ...!</font></font></a></div>');
							}
						}
					});	
			}
			jQuery.ajax({
				type: "POST",
				url: ajaxurl,
				data: {
						post_offset: postOffset,
						posts_per_page: PerPage,
						product_cat_arr: arr_cat,
						pricepara:price_val,
						orderby:orderby_val
				},
				cache: false,
				success: function (data) {
					countprodcuts_arr();
					var arr = $.parseJSON(data); 
					$(".product_id").empty();
					$.each(arr,function(key,value){
						var get_id= value.get_id;
						var image= value.image;
						var get_price= value.get_price;
						var get_permalink= value.get_permalink;
						var get_the_content= value.get_the_content;
						var get_permalink= value.get_permalink;
						var get_the_title= value.get_the_title;
						
						$('.product_id').append('<div class="col-sm-4"><a href="'+get_permalink+'" class="list-product-ui aos-init aos-animate" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><figure><img src="'+image+'" data-id="'+get_id+'"></figure><div class="figure-content"><div class="price-value"><label>Vanaf</label><span><?php echo get_woocommerce_currency_symbol();?>  '+get_price+'</span></div><div class="name-flower">'+get_the_title+'</div></div></a></div>');
					});
				},
				error: function () {
				}
			});	
		 }
});
</script>
 <script>
 //Load more code start
$('.load-more').click( function(e){
	$('.loader').css('display','block');
	$('.product-listing').css('opacity','.5'); 
		var price_val = $('.price_val').val();
	var orderby_val = $('.orderby_val').val();
	var postOffset = $(this).attr("data-offset");
	var PerPage = 9;
    e.preventDefault();
	var arr_cat =[];
	var fields = $("input:checkbox[name=filterCheckbox]:checked").serializeArray(); 
	var counterLoad = 0;
	//alert(fields);
	var ajaxurl = 'http://infinoax.com/static/wp-bbb/ajax-product/';
		 if(fields.length == 1){
			 var cat_id = $("input:checkbox[name=filterCheckbox]:checked").attr('id');
			 //alert(cat_id);
			function countLoadprodcuts(){
				var postOffsetcount="";
				var PerPagecount=-1;
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {post_offset: postOffsetcount,posts_per_page: PerPagecount,product_cat: cat_id},
						cache: false,
						success: function (data) {
							$('.loader').css('display','none');
							$('.product-listing').css("opacity","1"); 
							var arr = $.parseJSON(data); 
							$.each(arr,function(key,value){
								counterLoad++;
							});
							//alert(counter);
							var newcounter =parseInt(counterLoad) - parseInt(postOffset);
							//alert(newcounter);
							if(newcounter < 10){
								$('.loadMoreCount').css('display', 'none');
							}else{
								$('.loadMoreCount').text("Laad meer producten ("+newcounter+")");
								$('.loadMoreCount').css('display', 'inline-block');
							}
						}
						
					});	
			}
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {
								post_offset: postOffset,
								posts_per_page: PerPage,
								product_cat: cat_id,
								pricepara:price_val,
								orderby:orderby_val
						},
						cache: false,
						success: function (data) {
							//alert(data);
							countLoadprodcuts();
							var arr = $.parseJSON(data); 
							//$(".product_id").empty();
							$.each(arr,function(key,value){
								var get_id= value.get_id;
								var image= value.image;
								var get_price= value.get_price;
								var get_permalink= value.get_permalink;
								var get_the_content= value.get_the_content;
								var get_permalink= value.get_permalink;
								var get_the_title= value.get_the_title;
								
								$('.product_id').append('<div class="col-sm-4"><a href="'+get_permalink+'" class="list-product-ui aos-init aos-animate" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><figure><img src="'+image+'" data-id="'+get_id+'"></figure><div class="figure-content"><div class="price-value"><label>Vanaf</label><span><?php echo get_woocommerce_currency_symbol();?>  '+get_price+'</span></div><div class="name-flower">'+get_the_title+'</div></div></a></div>');
						
							}); 
							var newpostOffset =parseInt(postOffset) + parseInt(9);
							$('.load-more').attr('data-offset', newpostOffset);
						},
						error: function () {
						}
					});	
			 
		 }else if(fields.length > 1){
			$("input:checkbox[name=filterCheckbox]:checked").each(function(index){
				arr_cat.push($(this).attr("id"));
			}); 
			var counterLoad_arr =0;
		function countLoadprodcuts_arr(){
				var postOffsetcount="";
				var PerPagecount=-1;
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {post_offset: postOffsetcount,posts_per_page: PerPagecount,product_cat_arr: arr_cat},
						cache: false,
						success: function (data) {
							$('.loader').css('display','none');
							$('.product-listing').css("opacity","1"); 
							var arr = $.parseJSON(data); 
							$.each(arr,function(key,value){
								counterLoad_arr++;
							});
							//alert(counter_arr);
							var newcounter =parseInt(counterLoad_arr) - parseInt(postOffset);
							if(newcounter < 10){
								$('.loadMoreCount').css('display', 'none');
							}else{
								$('.loadMoreCount').text("Laad meer producten ("+newcounter+")");
								$('.loadMoreCount').css('display', 'inline-block');
							}
						}
						
					});	
			}
			jQuery.ajax({
				type: "POST",
				url: ajaxurl,
				data: {
						post_offset: postOffset,
						posts_per_page: PerPage,
						product_cat_arr: arr_cat,
						pricepara:price_val,
						orderby:orderby_val
				},
				cache: false,
				success: function (data) {
					countLoadprodcuts_arr();
					var arr = $.parseJSON(data); 
					//$(".product_id").empty();
					$.each(arr,function(key,value){
						var get_id= value.get_id;
						var image= value.image;
						var get_price= value.get_price;
						var get_permalink= value.get_permalink;
						var get_the_content= value.get_the_content;
						var get_permalink= value.get_permalink;
						var get_the_title= value.get_the_title;
						
						$('.product_id').append('<div class="col-sm-4"><a href="'+get_permalink+'" class="list-product-ui aos-init aos-animate" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><figure><img src="'+image+'" data-id="'+get_id+'"></figure><div class="figure-content"><div class="price-value"><label>Vanaf</label><span><?php echo get_woocommerce_currency_symbol();?>  '+get_price+'</span></div><div class="name-flower">'+get_the_title+'</div></div></a></div>');
					}); 
					var newpostOffset = parseInt(postOffset) + parseInt(9);
					$('.load-more').attr('data-offset', newpostOffset);
				},
				error: function () {
				}
			});	
		 }else{
			 var cat_id= "";	
			var counterNocat =0;
			function countLoadNocat(){
				var postOffsetcount="";
				var PerPagecount=-1;
				
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {post_offset: postOffsetcount,posts_per_page: PerPagecount,product_noCat: cat_id},
						cache: false,
						success: function (data) {
							$('.loader').css('display','none');
							$('.product-listing').css("opacity","1"); 
							var arr = $.parseJSON(data); 
							$.each(arr,function(key,value){
								counterNocat++;
							});
							//alert(counter);
							var newcounter =parseInt(counterNocat) - parseInt(postOffset);
							//alert(newcounter);
							if(newcounter < 10){
								$('.loadMoreCount').css('display', 'none');
							}else{
								$('.loadMoreCount').text("Laad meer producten ("+newcounter+")");
								$('.loadMoreCount').css('display', 'inline-block');
							}
						}
						
					});	
			}
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {
								post_offset: postOffset,
								posts_per_page: PerPage,
								product_noCat: cat_id,
								pricepara:price_val,
								orderby:orderby_val
						},
						cache: false,
						success: function (data) {
							//alert(data);
							countLoadNocat();
							var arr = $.parseJSON(data); 
							//$(".product_id").empty();
							$.each(arr,function(key,value){
								var get_id= value.get_id;
								var image= value.image;
								var get_price= value.get_price;
								var get_permalink= value.get_permalink;
								var get_the_content= value.get_the_content;
								var get_permalink= value.get_permalink;
								var get_the_title= value.get_the_title;
								
								$('.product_id').append('<div class="col-sm-4"><a href="'+get_permalink+'" class="list-product-ui aos-init aos-animate" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><figure><img src="'+image+'" data-id="'+get_id+'"></figure><div class="figure-content"><div class="price-value"><label>Vanaf</label><span><?php echo get_woocommerce_currency_symbol();?>  '+get_price+'</span></div><div class="name-flower">'+get_the_title+'</div></div></a></div>');
						
							}); 
							var newpostOffset =parseInt(postOffset) + parseInt(9);
							$('.load-more').attr('data-offset', newpostOffset);
						},
						error: function () {
						}
					});	
		 }
});
//price filtes
$("select#sel1").change(function(){
	
var filterVal = $("#sel1 option:selected" ).val();
var url = window.location.href; 
var hostnamesel1 = window.location.hostname; 
var urlpathname = window.location.pathname; 

if(filterVal == "newpopular"){
	$('.price_val').val('');
	$('.orderby_val').val('DESC');
	// window.location.href = "http://"+hostnamesel1+urlpathname;
			$('.loader').css('display','block');
	$('.product-listing').css('opacity','.5'); 
	$('.load-more').attr('data-offset', 9);
	var price_val ="";
	var orderby_val ="DESC";
	var arr_cat =[];
	var postOffset="";
	var PerPage = 9;				
	var cat_id = $("input:checkbox[name=filterCheckbox]:checked").attr("id");
	if(cat_id == "all"){
		 location.reload();
	}
	if(typeof (cat_id) == "undefined"){
		 location.reload();
	}
	var fields = $("input:checkbox[name=filterCheckbox]:checked").serializeArray(); 
	//alert(fields.length);
	var counter = 0;
	var ajaxurl = 'http://infinoax.com/static/wp-bbb/ajax-product/';
		 if(fields.length == 1){
			 var cat_id = $("input:checkbox[name=filterCheckbox]:checked").attr("id");
			function countprodcuts(){
				var postOffsetcount="";
				var PerPagecount=-1;
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {post_offset: postOffsetcount,posts_per_page: PerPagecount,product_cat:cat_id,pricepara:price_val,orderby:orderby_val},
						cache: false,
						success: function (data) {
							$('.loader').css('display','none');
							$('.product-listing').css("opacity","1"); 
							var arr = $.parseJSON(data); 
							$.each(arr,function(key,value){
								counter++;
							});
							//alert(counter);
							//alert(counter);
							var newcounter =parseInt(counter) - parseInt(9);
							if(newcounter < 1){
								$('.loadMoreCount').css('display', 'none');
							}else{
								$('.loadMoreCount').text("Laad meer producten ("+newcounter+")");
								$('.loadMoreCount').css('display', 'inline-block');
							}
							if(counter == 0){
								$('.product_id').append('<div class="load-more-product aos-init aos-animate nofound" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><a href="javascript:void(0);" class=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Geen product gevonden ...!</font></font></a></div>');
							}
						
						}
						
					});	
			}
			var noproduct = 0;
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {
								post_offset: postOffset,
								posts_per_page: PerPage,
								product_cat: cat_id,
								pricepara:price_val,
								orderby:orderby_val
						},
						cache: false,
						success: function (data) {
							countprodcuts();
							var arr = $.parseJSON(data); 
							$(".product_id").empty();
							$.each(arr,function(key,value){
								var get_id= value.get_id;
								var image= value.image;
								var get_price= value.get_price;
								var get_permalink= value.get_permalink;
								var get_the_content= value.get_the_content;
								var get_permalink= value.get_permalink;
								var get_the_title= value.get_the_title;
								
								$('.product_id').append('<div class="col-sm-4"><a href="'+get_permalink+'" class="list-product-ui aos-init aos-animate" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><figure><img src="'+image+'" data-id="'+get_id+'"></figure><div class="figure-content"><div class="price-value"><label>Vanaf</label><span><?php echo get_woocommerce_currency_symbol();?>  '+get_price+'</span></div><div class="name-flower">'+get_the_title+'</div></div></a></div>');
						noproduct++;
							}); 
						},
						error: function () {
						}
					});	
		 }else{
			$("input:checkbox[name=filterCheckbox]:checked").each(function(index){
				arr_cat.push($(this).attr("id"));
			}); 
			var counter_arr =0;
		function countprodcuts_arr(){
				var postOffsetcount="";
				var PerPagecount=-1;
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {post_offset: postOffsetcount,posts_per_page: PerPagecount,product_cat_arr: arr_cat,pricepara:price_val,orderby:orderby_val},
						cache: false,
						success: function (data) {
							$('.loader').css('display','none');
							$('.product-listing').css("opacity","1"); 
							var arr = $.parseJSON(data); 
							$.each(arr,function(key,value){
								counter_arr++;
							});
							//alert(counter_arr);
							var newcounter =parseInt(counter_arr) - parseInt(9);
							if(newcounter < 1){
								$('.loadMoreCount').css('display', 'none');
							}else{
								$('.loadMoreCount').text("Laad meer producten ("+newcounter+")");
								$('.loadMoreCount').css('display', 'inline-block');
							}
						if(counter_arr == 0){
								$('.product_id').append('<div class="load-more-product aos-init aos-animate nofound" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><a href="javascript:void(0);" class=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Geen product gevonden ...!</font></font></a></div>');
							}
						}
					});	
			}
			jQuery.ajax({
				type: "POST",
				url: ajaxurl,
				data: {
						post_offset: postOffset,
						posts_per_page: PerPage,
						product_cat_arr: arr_cat,
						pricepara:price_val,
						orderby:orderby_val
				},
				cache: false,
				success: function (data) {
					countprodcuts_arr();
					var arr = $.parseJSON(data); 
					$(".product_id").empty();
					$.each(arr,function(key,value){
						var get_id= value.get_id;
						var image= value.image;
						var get_price= value.get_price;
						var get_permalink= value.get_permalink;
						var get_the_content= value.get_the_content;
						var get_permalink= value.get_permalink;
						var get_the_title= value.get_the_title;
						
						$('.product_id').append('<div class="col-sm-4"><a href="'+get_permalink+'" class="list-product-ui aos-init aos-animate" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><figure><img src="'+image+'" data-id="'+get_id+'"></figure><div class="figure-content"><div class="price-value"><label>Vanaf</label><span><?php echo get_woocommerce_currency_symbol();?>  '+get_price+'</span></div><div class="name-flower">'+get_the_title+'</div></div></a></div>');
					});
				},
				error: function () {
				}
			});	
		 }
	
}
if(filterVal == "lowtohiegh"){
	 //window.location.href = "http://"+hostnamesel1+urlpathname+"?price=_price&orderby=ASC";
	 $('.price_val').val('_price');
	$('.orderby_val').val('ASC'); 
	$('.loader').css('display','block');
	$('.product-listing').css('opacity','.5'); 
	$('.load-more').attr('data-offset', 9);
	var price_val ="_price";
	var orderby_val ="ASC";
	var arr_cat =[];
	var postOffset="";
	var PerPage = 9;				
	var cat_id = $("input:checkbox[name=filterCheckbox]:checked").attr("id");
	if(cat_id == "all"){
		 location.reload();
	}
	if(typeof (cat_id) == "undefined"){
		 location.reload();
	}
	var fields = $("input:checkbox[name=filterCheckbox]:checked").serializeArray(); 
	//alert(fields.length);
	var counter = 0;
	var ajaxurl = 'http://infinoax.com/static/wp-bbb/ajax-product/';
		 if(fields.length == 1){
			 var cat_id = $("input:checkbox[name=filterCheckbox]:checked").attr("id");
			function countprodcuts(){
				var postOffsetcount="";
				var PerPagecount=-1;
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {post_offset: postOffsetcount,posts_per_page: PerPagecount,product_cat:cat_id,pricepara:price_val,orderby:orderby_val},
						cache: false,
						success: function (data) {
							$('.loader').css('display','none');
							$('.product-listing').css("opacity","1"); 
							var arr = $.parseJSON(data); 
							$.each(arr,function(key,value){
								counter++;
							});
							//alert(counter);
							//alert(counter);
							var newcounter =parseInt(counter) - parseInt(9);
							if(newcounter < 1){
								$('.loadMoreCount').css('display', 'none');
							}else{
								$('.loadMoreCount').text("Laad meer producten ("+newcounter+")");
								$('.loadMoreCount').css('display', 'inline-block');
							}
							if(counter == 0){
								$('.product_id').append('<div class="load-more-product aos-init aos-animate nofound" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><a href="javascript:void(0);" class=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Geen product gevonden ...!</font></font></a></div>');
							}
						
						}
						
					});	
			}
			var noproduct = 0;
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {
								post_offset: postOffset,
								posts_per_page: PerPage,
								product_cat: cat_id,
								pricepara:price_val,
								orderby:orderby_val
						},
						cache: false,
						success: function (data) {
							countprodcuts();
							var arr = $.parseJSON(data); 
							$(".product_id").empty();
							$.each(arr,function(key,value){
								var get_id= value.get_id;
								var image= value.image;
								var get_price= value.get_price;
								var get_permalink= value.get_permalink;
								var get_the_content= value.get_the_content;
								var get_permalink= value.get_permalink;
								var get_the_title= value.get_the_title;
								
								$('.product_id').append('<div class="col-sm-4"><a href="'+get_permalink+'" class="list-product-ui aos-init aos-animate" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><figure><img src="'+image+'" data-id="'+get_id+'"></figure><div class="figure-content"><div class="price-value"><label>Vanaf</label><span><?php echo get_woocommerce_currency_symbol();?>  '+get_price+'</span></div><div class="name-flower">'+get_the_title+'</div></div></a></div>');
						noproduct++;
							}); 
						},
						error: function () {
						}
					});	
		 }else{
			$("input:checkbox[name=filterCheckbox]:checked").each(function(index){
				arr_cat.push($(this).attr("id"));
			}); 
			var counter_arr =0;
		function countprodcuts_arr(){
				var postOffsetcount="";
				var PerPagecount=-1;
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {post_offset: postOffsetcount,posts_per_page: PerPagecount,product_cat_arr: arr_cat,pricepara:price_val,orderby:orderby_val},
						cache: false,
						success: function (data) {
							$('.loader').css('display','none');
							$('.product-listing').css("opacity","1"); 
							var arr = $.parseJSON(data); 
							$.each(arr,function(key,value){
								counter_arr++;
							});
							//alert(counter_arr);
							var newcounter =parseInt(counter_arr) - parseInt(9);
							if(newcounter < 1){
								$('.loadMoreCount').css('display', 'none');
							}else{
								$('.loadMoreCount').text("Laad meer producten ("+newcounter+")");
								$('.loadMoreCount').css('display', 'inline-block');
							}
						if(counter_arr == 0){
								$('.product_id').append('<div class="load-more-product aos-init aos-animate nofound" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><a href="javascript:void(0);" class=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Geen product gevonden ...!</font></font></a></div>');
							}
						}
					});	
			}
			jQuery.ajax({
				type: "POST",
				url: ajaxurl,
				data: {
						post_offset: postOffset,
						posts_per_page: PerPage,
						product_cat_arr: arr_cat,
						pricepara:price_val,
						orderby:orderby_val
				},
				cache: false,
				success: function (data) {
					countprodcuts_arr();
					var arr = $.parseJSON(data); 
					$(".product_id").empty();
					$.each(arr,function(key,value){
						var get_id= value.get_id;
						var image= value.image;
						var get_price= value.get_price;
						var get_permalink= value.get_permalink;
						var get_the_content= value.get_the_content;
						var get_permalink= value.get_permalink;
						var get_the_title= value.get_the_title;
						
						$('.product_id').append('<div class="col-sm-4"><a href="'+get_permalink+'" class="list-product-ui aos-init aos-animate" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><figure><img src="'+image+'" data-id="'+get_id+'"></figure><div class="figure-content"><div class="price-value"><label>Vanaf</label><span><?php echo get_woocommerce_currency_symbol();?>  '+get_price+'</span></div><div class="name-flower">'+get_the_title+'</div></div></a></div>');
					});
				},
				error: function () {
				}
			});	
		 }
}
if(filterVal == "heighttolow"){
		//window.location.href = "http://"+hostnamesel1+urlpathname+"?price=_price&orderby=DESC";
	 $('.price_val').val('_price');
	$('.orderby_val').val('DESC');
	$('.loader').css('display','block');
	$('.product-listing').css('opacity','.5'); 
	$('.load-more').attr('data-offset', 9);
	var price_val ="_price";
	var orderby_val ="DESC";
	var arr_cat =[];
	var postOffset="";
	var PerPage = 9;				
	var cat_id = $("input:checkbox[name=filterCheckbox]:checked").attr("id");
	if(cat_id == "all"){
		 location.reload();
	}
	if(typeof (cat_id) == "undefined"){
		 location.reload();
	}
	var fields = $("input:checkbox[name=filterCheckbox]:checked").serializeArray(); 
	//alert(fields.length);
	var counter = 0;
	var ajaxurl = 'http://infinoax.com/static/wp-bbb/ajax-product/';
		 if(fields.length == 1){
			 var cat_id = $("input:checkbox[name=filterCheckbox]:checked").attr("id");
			function countprodcuts(){
				var postOffsetcount="";
				var PerPagecount=-1;
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {post_offset: postOffsetcount,posts_per_page: PerPagecount,product_cat:cat_id,pricepara:price_val,orderby:orderby_val},
						cache: false,
						success: function (data) {
							$('.loader').css('display','none');
							$('.product-listing').css("opacity","1"); 
							var arr = $.parseJSON(data); 
							$.each(arr,function(key,value){
								counter++;
							});
							//alert(counter);
							//alert(counter);
							var newcounter =parseInt(counter) - parseInt(9);
							if(newcounter < 1){
								$('.loadMoreCount').css('display', 'none');
							}else{
								$('.loadMoreCount').text("Laad meer producten ("+newcounter+")");
								$('.loadMoreCount').css('display', 'inline-block');
							}
							if(counter == 0){
								$('.product_id').append('<div class="load-more-product aos-init aos-animate nofound" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><a href="javascript:void(0);" class=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Geen product gevonden ...!</font></font></a></div>');
							}
						
						}
						
					});	
			}
			var noproduct = 0;
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {
								post_offset: postOffset,
								posts_per_page: PerPage,
								product_cat: cat_id,
								pricepara:price_val,
								orderby:orderby_val
						},
						cache: false,
						success: function (data) {
							countprodcuts();
							var arr = $.parseJSON(data); 
							$(".product_id").empty();
							$.each(arr,function(key,value){
								var get_id= value.get_id;
								var image= value.image;
								var get_price= value.get_price;
								var get_permalink= value.get_permalink;
								var get_the_content= value.get_the_content;
								var get_permalink= value.get_permalink;
								var get_the_title= value.get_the_title;
								
								$('.product_id').append('<div class="col-sm-4"><a href="'+get_permalink+'" class="list-product-ui aos-init aos-animate" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><figure><img src="'+image+'" data-id="'+get_id+'"></figure><div class="figure-content"><div class="price-value"><label>Vanaf</label><span><?php echo get_woocommerce_currency_symbol();?>  '+get_price+'</span></div><div class="name-flower">'+get_the_title+'</div></div></a></div>');
						noproduct++;
							}); 
						},
						error: function () {
						}
					});	
		 }else{
			$("input:checkbox[name=filterCheckbox]:checked").each(function(index){
				arr_cat.push($(this).attr("id"));
			}); 
			var counter_arr =0;
		function countprodcuts_arr(){
				var postOffsetcount="";
				var PerPagecount=-1;
					jQuery.ajax({
						type: "POST",
						url: ajaxurl,
						data: {post_offset: postOffsetcount,posts_per_page: PerPagecount,product_cat_arr: arr_cat,pricepara:price_val,orderby:orderby_val},
						cache: false,
						success: function (data) {
							$('.loader').css('display','none');
							$('.product-listing').css("opacity","1"); 
							var arr = $.parseJSON(data); 
							$.each(arr,function(key,value){
								counter_arr++;
							});
							//alert(counter_arr);
							var newcounter =parseInt(counter_arr) - parseInt(9);
							if(newcounter < 1){
								$('.loadMoreCount').css('display', 'none');
							}else{
								$('.loadMoreCount').text("Laad meer producten ("+newcounter+")");
								$('.loadMoreCount').css('display', 'inline-block');
							}
						if(counter_arr == 0){
								$('.product_id').append('<div class="load-more-product aos-init aos-animate nofound" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><a href="javascript:void(0);" class=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Geen product gevonden ...!</font></font></a></div>');
							}
						}
					});	
			}
			jQuery.ajax({
				type: "POST",
				url: ajaxurl,
				data: {
						post_offset: postOffset,
						posts_per_page: PerPage,
						product_cat_arr: arr_cat,
						pricepara:price_val,
						orderby:orderby_val
				},
				cache: false,
				success: function (data) {
					countprodcuts_arr();
					var arr = $.parseJSON(data); 
					$(".product_id").empty();
					$.each(arr,function(key,value){
						var get_id= value.get_id;
						var image= value.image;
						var get_price= value.get_price;
						var get_permalink= value.get_permalink;
						var get_the_content= value.get_the_content;
						var get_permalink= value.get_permalink;
						var get_the_title= value.get_the_title;
						
						$('.product_id').append('<div class="col-sm-4"><a href="'+get_permalink+'" class="list-product-ui aos-init aos-animate" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100ms"><figure><img src="'+image+'" data-id="'+get_id+'"></figure><div class="figure-content"><div class="price-value"><label>Vanaf</label><span><?php echo get_woocommerce_currency_symbol();?>  '+get_price+'</span></div><div class="name-flower">'+get_the_title+'</div></div></a></div>');
					});
				},
				error: function () {
				}
			});	
		 }	
}
});
$('.quantity').addClass("block-product-detail");

var errosDiv = $('.woocommerce-notices-wrapper').html();
$('.errorsDiv').append(errosDiv);


$('.cartBtn').click( function(){
 $( ".single_add_to_cart_button" ).trigger( "click" );
});

$('.checkVal').click( function(){
	var extraCheckboxVal = $("input:checkbox[name=extraCheckbox]:checked").val();
	var checkVal = $(".checkVal").val();
	//alert(checkVal);
	if(checkVal == 0){
		$('.checkVal').val(1);
		$('.extraCheckbox').val(1);
		$(".chckValid").prop('required',true);
		$('.prodctHidden').css("display","block");
		$('.prodcutCustom').css("display","block");
		$('.textareaProduct').css("display","block");
		$('.filedCheckbox').css("top","42%");
	}else{
		$('.checkVal').val(0);
		$('.extraCheckbox').val(0);
		$(".chckValid").prop('required',false);
		$('.prodctHidden').css("display","none");
		$('.prodcutCustom').css("display","none");
		$('.textareaProduct').css("display","none");
		$('.filedCheckbox').css("top","75%");
	}

});

  $('.bezocheck-container input:radio').change(function(){
	    if($('.toggle_bezorgadres input:radio').is(":checked")) {
	        $('.tbezorgadres').slideDown();
	    } else {
	        $('.tbezorgadres').slideUp();
	    }
	});
	 
$('#quickOrder').on('change', function() {
		var productId = this.value;
	 // $("#quickAction").attr("action", "/static/wp-bbb/snell-bestellen/?add-to-cart="+productId);
});

$('#numberCard').on('change', function() {
		var productId =parseInt(this.value);
		
	//	alert(productId);
		$('.qty').attr('value', productId);
	 
});
$('.woocommerce-message, .tteaa').fadeOut(5000);
  //$("#div3").fadeOut(3000);
  $('.deleiveryAddress').click(function(){
	  var valshiping = $(this).attr("data-id");
	  //alert(valshiping);
	  if(valshiping == 1){
		  $('#ship-to-different-address-checkbox').prop('checked', true);
		  $('.deleiveryAddress').attr("data-id", '0');
		  $('.shipTitle').css("display",'block');
		  $('.shippingDiv').css("display",'block');
		 // $('#ship-to-different-address').css("top","45%");
		  $(".shippingFields").prop('required',true);
	  }else{
		  $('#ship-to-different-address-checkbox').prop('checked', false);
		  $('.deleiveryAddress').attr("data-id", '1');
		    $('.shipTitle').css("display",'none');
		  $('.shippingDiv').css("display",'none');
		//  $('#ship-to-different-address').css("top","88%");
		  $(".shippingFields").prop('required',false);
	  }
  }); 
  
  	var fieldsshop = $("input:checkbox[name=filterCheckbox]:checked").serializeArray(); 
	
 //alert(fieldsshop.length);
  if(fieldsshop.length > 0){
	  window.location.reload();
  }

 if( $('.wpcf7-response-output').is('.wpcf7-mail-sent-ok') ){
   var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 

  modal.style.display = "block";


// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
}

$('.btn-white-block').click( function(){
window.history.pushState('page2', 'Title', '/static/wp-bbb/contact/');

});

$('.btn-black').click(function(){
		var quickOrder = $( "#quickOrder option:selected" ).val();
		if(quickOrder == ""){
			$('.selectValue').css("display","block");
		}
		var Vaascheckbox =$('.Vaascheckbox').val();
		if(Vaascheckbox == ""){
			$('.Vaas').css("display","block");
		}
		var numberCard =$('#numberCard option:selected').val();
		if(numberCard == ""){
			$('.Aantal').css("display","block");
		}
		var liverRadio =$('.liverRadio').val();
		if(liverRadio == ""){
			$('.liever').css("display","block");
		}

});


</script>
  
</html>