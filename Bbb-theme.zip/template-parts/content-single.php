<?php
/**
 * The template part for displaying single posts
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 session_start();
 if ( is_singular( 'product' ) ) {
	 
$cookie_name = "shop";
$cookie_value = "shopPage";
setcookie($cookie_name, $cookie_value, time() + (86400 * 365), "/"); 

	 global $product;
	   global $woocommerce;
	  $cartCount = $woocommerce->cart->cart_contents_count;

if($cartCount == 0){
	unset($_SESSION['product_session_id']);
}
 /* 
 if($product->get_id() == 205){ 
	
	echo $product->get_id();
		function kia_dropdown_option(){
			
	
		printf( ' <div class="order-form-field">
                    <div class="form-fieldset">
					<select name="boeketCount" class="selectpicker custom-select-style"><option value="" selected disabled>Boeket</option><option value="1">Boeket option 1</option><option value="2">Boeket option 2</option><option value="3">Boeket option 3</option><option value="4">Boeket option 4</option></select>
					</div>
					</div>
					<div class="custom-checkbox">
                    <label>
                      <input type="checkbox" name="checkboxBooket" value="checkboxvalue">
                      <span>Vaas (helder glas)</span>
                    </label>
                  </div>
				  <br><br>
				  <div class="order-form-field">
                    <div class="form-fieldset">
                      <select name="numberCard" class="selectpicker custom-select-style">
                        <option value="" selected disabled>Aantal</option>
                        <option value="Aantal option 1">Aantal option 1</option>
                        <option value="Aantal option 2">Aantal option 2</option>
                        <option value="Aantal option 3">Aantal option 3</option>
                        <option value="Aantal option 4">Aantal option 4</option>
                      </select>
                    </div>
                  </div>
				  <div class="field-set onclick">
                    <textarea name="cardWords" class="text-field" id="message"></textarea>
                    <label for="message">Tekst kaartje:</label>
                    <span class="note-textarea">Maximaal 50 woorden</span>
                  </div>', __( '', 'kia-plugin-textdomain' ), esc_attr( $value ) );
		}
		add_action( 'woocommerce_before_add_to_cart_button', 'kia_dropdown_option', 10 );
		

		function kia_add_cart_single_data( $cart_item, $product_id ){
			
			echo  $_POST['boeketCount'];
			
		 
			if( isset( $_POST['boeketCount'] ) ) {
				$cart_item['boeketCount'] = sanitize_text_field( $_POST['boeketCount'] );
			}
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_add_cart_item_data', 'kia_add_cart_single_data', 10, 2 );


		 function kia_get_cart_item_single_session( $cart_item, $values ) {
		 
			if ( isset( $values['boeketCount'] ) ){
				$cart_item['boeketCount'] = $values['boeketCount'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_get_cart_item_from_session', 'kia_get_cart_item_single_session', 20, 2 );

		function kia_add_order_item_single_meta( $item_id, $values ) {
		 
			if ( ! empty( $values['boeketCount'] ) ) {
				woocommerce_add_order_item_meta( $item_id, 'boeketCount', $values['boeketCount'] );           
			}
		}
		add_action( 'woocommerce_add_order_item_meta', 'kia_add_order_item_single_meta', 10, 2 );

		function kia_get_item_single_data( $other_data, $cart_item ) {
		 
			if ( isset( $cart_item['boeketCount'] ) ){
		 
				$other_data[] = array(
					'name' => __( 'Your custom text', 'kia-plugin-textdomain' ),
					'value' => sanitize_text_field( $cart_item['boeketCount'] )
				);
		 
			}
		 
			return $other_data;
		 
		}
		add_filter( 'woocommerce_get_item_data', 'kia_get_item_single_data', 10, 2 );

		function kia_order_item_single_product( $cart_item, $order_item ){
		 
			if( isset( $order_item['boeketCount'] ) ){
				$cart_item_meta['boeketCount'] = $order_item['boeketCount'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_item_product', 'kia_order_item_single_product', 10, 2 );

		function kia_email_order_meta_single_fields( $fields ) { 
			$fields['custom_field'] = __( 'Your custom text', 'kia-plugin-textdomain' ); 
			return $fields; 
		} 
		add_filter('woocommerce_email_order_meta_fields', 'kia_email_order_meta_single_fields');

		function kia_order_again_cart__single_item_data( $cart_item, $order_item, $order ){
		 
			if( isset( $order_item['boeketCount'] ) ){
				$cart_item_meta['boeketCount'] = $order_item['boeketCount'];
			}
		 
			return $cart_item;
		 
		}
		add_filter( 'woocommerce_order_again_cart_item_data', 'kia_order_again_cart__single_item_data', 10, 3 ); 
 
}
*/

  global $product;

$categoryArr = array();

$product_cats_ids = wc_get_product_term_ids( $product->get_id(), 'product_cat' );
foreach( $product_cats_ids as $cat_id ) {
    $term = get_term_by( 'id', $cat_id, 'product_cat' );
$_product = wc_get_product( $product->get_id());
/* echo "<pre>";
print_r($term); */
    $categoryArr[] =  $term->term_id;
}


	if (in_array(35, $categoryArr))
	{
		function kia_checkbox_option(){
	/* 	global $wpdb;
		 $table_name = $wpdb->prefix . 'ribbon';
			$session_id =$_SESSION["product_session_id"];
			$result=$wpdb->get_results( "SELECT * FROM $table_name WHERE product_session_id ='$session_id'");
					
					$rowcount = $wpdb->num_rows;
					if($rowcount != 0 ){
						$checkboxVal =$result[0]->checkboxVal;
							if($checkboxVal != 0){
							printf( '<div class="custom-checkbox filedCheckbox"><label><input type="checkbox" class="checkVal" name="checkVal" value="'.$checkboxVal.'" checked><span>Voeg een rouwlint toe (meerprijs € 17.50)</span></label></div>', __( '', 'kia-plugin-textdomain' ), esc_attr( $value ) );
							}else{
							
								printf( '<div class="custom-checkbox filedCheckbox"><label><input type="checkbox" class="checkVal" name="checkVal" value="0"><span>Voeg een rouwlint toe (meerprijs € 17,50)</span></label></div>', __( '', 'kia-plugin-textdomain' ), esc_attr( $value ) );
							}
					
						}else{ */
						printf( '<div class="custom-checkbox filedCheckbox"><label><input type="checkbox" class="checkVal" name="checkVal" value="0"><span>Voeg een rouwlint toe (meerprijs € 17,50)</span></label></div>', __( '', 'kia-plugin-textdomain' ), esc_attr( $value ) );
						//}
		}
		add_action( 'woocommerce_before_add_to_cart_button', 'kia_checkbox_option', 10 );
		
		
		function kia_custom_option(){
/* 			global $wpdb;
		 $table_name = $wpdb->prefix . 'ribbon';
			$session_id =$_SESSION["product_session_id"];
			$result=$wpdb->get_results( "SELECT * FROM $table_name WHERE product_session_id ='$session_id'");
					
					$rowcount = $wpdb->num_rows;
					if($rowcount != 0 ){
						$custom_option =$result[0]->custom_option;
						$checkboxVal =$result[0]->checkboxVal;

					
					printf( '<div class="block-field-ribbon prodcutCustom"><fieldset><input name="rouwlint1" class="text-field chckValid" placeholder="Rouwlint linker slip" value="'.$custom_option.'" /></fieldset>', __( '', 'kia-plugin-textdomain' ), esc_attr( $value ) );
						}else{ */
						printf( '<div class="block-field-ribbon prodcutCustom"><fieldset><input name="rouwlint1" class="text-field chckValid" placeholder="Rouwlint linker slip" value="%s" /></fieldset>', __( '', 'kia-plugin-textdomain' ), esc_attr( $value ) );
						//}
		}
		add_action( 'woocommerce_before_add_to_cart_button', 'kia_custom_option', 10 );

		function secod_custom_option(){
		/* 	global $wpdb;
			 $table_name = $wpdb->prefix . 'ribbon';
			$session_id =$_SESSION["product_session_id"];
			$result=$wpdb->get_results( "SELECT * FROM $table_name WHERE product_session_id ='$session_id'");
				
				$rowcount = $wpdb->num_rows;
				if($rowcount != 0 ){
					$custom_option2 =$result[0]->custom_option2;
					printf( '<fieldset><input name="rouwlint2" class="text-field chckValid" placeholder="Rouwlint linker slip" value="'.$custom_option2.'" /></fieldset></div>', __( '', 'kia-plugin-textdomain' ), esc_attr( $value ) );
						}else{ */
							printf( '<fieldset><input name="rouwlint2" class="text-field chckValid" placeholder="Rouwlint linker slip" value="%s" /></fieldset></div>', __( '', 'kia-plugin-textdomain' ), esc_attr( $value ) );
						//}

		}
		add_action( 'woocommerce_before_add_to_cart_button', 'secod_custom_option', 10 );

		function third_custom_option(){
	/* 		global $wpdb;
			 $table_name = $wpdb->prefix . 'ribbon';
			$session_id =$_SESSION["product_session_id"];
			$result=$wpdb->get_results( "SELECT * FROM $table_name WHERE product_session_id ='$session_id'");
			
				$rowcount = $wpdb->num_rows;
				if($rowcount != 0 ){	
					$card_descp =$result[0]->card_descp;				
					$value = isset( $_POST['boodschap'] ) ? sanitize_text_field( $_POST['boodschap'] ) : '';
					printf( '<div class="add-to-cart-disc textareaProduct"><label>Voeg een kaartje toe aan uw boeket</label><div class="block-field-ribbon"><textarea class="chckValid" name="boodschap" placeholder="Voer hier uw boodschap in..." >'.$card_descp.'</textarea></div></div>', __( '', 'kia-plugin-textdomain' ), esc_attr( $value ) );
						}else{
							$value = isset( $_POST['boodschap'] ) ? sanitize_text_field( $_POST['boodschap'] ) : ''; */
							printf( '<div class="add-to-cart-disc textareaProduct"><label>Voeg een kaartje toe aan uw boeket</label><div class="block-field-ribbon"><textarea class="chckValid" name="boodschap" placeholder="Voer hier uw boodschap in..." ></textarea></div></div>', __( '', 'kia-plugin-textdomain' ), esc_attr( $value ) );
						//}
		}
		add_action( 'woocommerce_before_add_to_cart_button', 'third_custom_option', 10 );
	}


				 if(isset($_POST['add-to-cart'])){
					  session_start();
					 global $wpdb;
					 if($_POST['checkVal'] != ""){
						$checkboxVal = $_POST['checkVal'];
					 }else{
						 $checkboxVal =0;
					 }
					global $product;
					 $product_id = $product->get_id();
					 if($checkboxVal == 1){
							$custom_option = $_POST['rouwlint1'];
							$custom_option2 = $_POST['rouwlint2'];
							$card_descp = $_POST['boodschap'];
							$extra_charge = 17.50;
							global $wpdb;
							$session_id =$_SESSION["product_session_id"];
							$table_name = $wpdb->prefix . 'ribbon';
							$result=$wpdb->get_results( "SELECT * FROM $table_name WHERE product_session_id ='$session_id' AND product_id = '".$product_id."'");
							$count = $wpdb->num_rows;
						 if($count != 0){
							  $table_name = $wpdb->prefix . 'ribbon';
							   $in = $wpdb->query("update `$table_name` set `custom_option`='$custom_option',`custom_option2`='$custom_option2',`card_descp`='$card_descp' WHERE product_session_id ='$session_id' AND product_id = '".$product_id."'");	 
						}else{
							
							$session_id =$_SESSION["product_session_id"];
							$funeralProduct = array();
							$table_name = $wpdb->prefix . 'ribbon';
							$result=$wpdb->get_results( "SELECT * FROM $table_name WHERE product_session_id ='$session_id'");
							$rowcount = $wpdb->num_rows;
							if($rowcount != 0 ){
								$free_product_id =$result[0]->product_id; 
								$cart_id = WC()->cart->generate_cart_id( $free_product_id ); 
								$free_products_in_cart = WC()->cart->find_product_in_cart( $cart_id );
								$cart_amount = WC()->cart->subtotal; // cart subtotal
								$result=$wpdb->get_results( "SELECT * FROM $table_name WHERE product_id ='$free_product_id'");
								$rowcount = $wpdb->num_rows;
									if($rowcount != 0 ){
										$in = $wpdb->query("DELETE FROM $table_name WHERE product_session_id ='$session_id'");	
									}
								WC()->cart->remove_cart_item( $free_product_id );
								WC()->cart->add_to_cart( $free_product_id, 1 ); 				
							}			 
						 $len = 10;
						 function randStrGen($len){
							$result = "";
							$chars = "abcdefghijklmnopqrstuvwxyz0123456789$11";
							$charArray = str_split($chars);
							for($i = 0; $i < $len; $i++){
								$randItem = array_rand($charArray);
								$result .= "".$charArray[$randItem];
							}
							return $result;
						}
						$product_session_id =  randStrGen($len);
						  $table_name = $wpdb->prefix . 'ribbon';
							$in = $wpdb->query("INSERT INTO `$table_name`(`product_id`, `extra_charge`, `product_session_id`,`checkboxVal`,`custom_option`,`custom_option2`,`card_descp`) VALUES ('".$product_id."', '".$_POST['extra_charge']."','$product_session_id','$checkboxVal','$custom_option','$custom_option2','$card_descp')");
						  if($in){
								session_start();
							  $_SESSION["product_session_id"] = $product_session_id;
							
						  } 
					 }
				}else{
					global $wpdb;
						$session_id =$_SESSION["product_session_id"];
						$result=$wpdb->get_results( "SELECT * FROM $table_name WHERE product_session_id ='$session_id' AND product_id = '".$product_id."'");
						$rowcount = $wpdb->num_rows;
							if($rowcount != 0 ){
								$in = $wpdb->query("DELETE FROM $table_name WHERE product_session_id ='$session_id' AND product_id = '".$product_id."'");	
							}
							  $_SESSION["product_session_id"] = "";
					
					
				}
	}
?>

<section class="prduct-detail-page prdctSingle">
          <div class="container">
            <div class="row">
              <div class="col-sm-6" data-aos="fade-right" data-aos-duration="600" data-aos-delay="370ms">
                <div class="product-detail-img">
				  <?php  
					  $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );
					  ?>
                  <img src="<?php  echo $image[0];?>" alt="" />
                </div>
              </div>
              <div class="col-sm-6" data-aos="fade-left" data-aos-duration="600" data-aos-delay="370ms">
                <div class="product-detail">
				
                  <p><?php echo $product->get_description(); ?></p>
				  <?php
				  	if( $_product->is_type( 'simple' ) ) {
				  ?>
				   <div class="block-product-detail">
                    <label>Prijs</label>
                    <div class="block-field-product"><span class="priceSingle"><?php echo get_woocommerce_currency_symbol();?> <?php echo $product->get_price();?> </span>
                     
                    </div>
                  </div>
				  <style>
				  
				  </style>
				  <?php
					}
						do_action( 'woocommerce_single_product_summary' );
				  if (in_array(35, $categoryArr))
					{
				  ?>
                  <div class="ribbon block-product-detail">
                    <label>Rouwlint</label>
                    <div class="block-field-product">
					<?php  $rouwlint = get_post_meta(get_the_ID(), 'Rouwlint', TRUE);?>
                      <p <?php if($rouwlint == ""){ ?> style="visibility:hidden;" <?php } ?>><?php echo get_post_meta(get_the_ID(), 'Rouwlint', TRUE);?></p>
                      <div class="custom-checkbox" style="visibility:hidden;">
                        <label>
                          <input type="checkbox" class="extraCheckbox" value="0" name="extraCheckbox">
                          <span>Voeg een rouwlint toe (meerprijs € 17,50)</span>
                        </label>
                      </div>
                      <div style="visibility:hidden;" class="block-field-ribbon prodctHidden">
                        <fieldset>
                          <input type="text" name="" class="text-field" placeholder="Rouwlint linker slip">
                        </fieldset>
                        <fieldset>
                          <input type="text" name="" class="text-field" placeholder="Rouwlint rechter slip">
                        </fieldset>
                      </div>
                    </div>
                  </div>
                  <div style="visibility:hidden;" class="add-to-cart-disc prodctHidden">
                    <label>Voeg een kaartje toe aan uw boeket</label>
                    <div class="block-field-ribbon">
                      <textarea placeholder="Voer hier uw boodschap in..."></textarea>
                    </div>
                </div>
				<?php
					}else{ ?>
					<style>
					.block-field-ribbon.prodcutCustom{
						display:none;
					}
					.add-to-cart-disc.textareaProduct{
						display:none;
					}
					</style>
					<?php
					}
				?>
				
                <div class="submit-form">
				<br><br>
                  <a href="javascript:void(0)" class="submit-btn cartBtn" data-toggle="modal" data-target="#success-message">Bestellen</a>
                </div>
              </div>
            </div>
          </div>
        </section>
<?php
} else {
	?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php the_title( '<h1 class="entry-title testsss">', '</h1>' ); ?>
	</header><!-- .entry-header -->

	<?php twentysixteen_excerpt(); ?>

	<?php twentysixteen_post_thumbnail(); ?>

	<div class="entry-content">
		<?php
			the_content();

			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentysixteen' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			) );

			if ( '' !== get_the_author_meta( 'description' ) ) {
				get_template_part( 'template-parts/biography' );
			}
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php twentysixteen_entry_meta(); ?>
		<?php
			edit_post_link(
				sprintf(
					/* translators: %s: Name of current post */
					__( 'Edit<span class="screen-reader-text"> "%s"</span>', 'twentysixteen' ),
					get_the_title()
				),
				'<span class="edit-link">',
				'</span>'
			);
		?>
	</footer><!-- .entry-footer -->
</article><!-- #post-## -->
<?php
}
?>