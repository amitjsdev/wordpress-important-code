<?php
/**
 * The template part for displaying results in search pages
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
 //if ( is_product()) {
  global $product;
?>
 
<div class="col-sm-3" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100">
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
             <div class="our-flowers-box">
                    <figure>
                      <a href="<?php echo $product->get_permalink();?>">
                        <?php  
					  $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );
					  ?>
						<img src="<?php  echo $image[0];?>" alt="" />
                      </a>
                    </figure>
                    <figcaption>
                      <h3 class="name-flower"><a href="<?php echo $product->get_permalink();?>"><?php echo $product->get_title(); ?></a></h3>
                      <span class="price-flower"><?php echo get_woocommerce_currency_symbol();?>  <?php echo $product->get_price();?></span>
                      <a href="<?php echo $product->get_permalink();?>" class="btn-cart"><img src="images/cart-icon.png" alt=""><span>Bestellen</span></a>
                    </figcaption>
                  </div>
</article>
</div>		
<?php

 //}
 ?>
	


