<?php
/**
 * Template name: Register
 */

get_header(); ?>


	<?php echo do_shortcode('[woocommerce_simple_registration]');?>

		
<?php get_footer(); ?>
