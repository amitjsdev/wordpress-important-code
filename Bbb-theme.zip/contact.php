<?php
/**
 * Template name: contact
 */

get_header(); ?>
 	<?php 
				while ( have_posts() ) : the_post();
				the_content();
				endwhile;  
				wp_reset_query(); ?>
        <section class="page-title-block" data-aos="fade-in" data-aos-duration="600" data-aos-delay="100">
          <div class="container">
            <h1><?php the_title();?></h1>
          </div>
        </section>
        <section class="contact-us">
          <div class="container">
            <div class="row">
              <div class="col-sm-3 timing-block-contact" data-aos="fade-up" data-aos-duration="600" data-aos-delay="100">
                <div class="open-timing">
       <?php dynamic_sidebar('sidebar-6');?>
                </div>
              </div>
              <div class="col-sm-4 contact-block-middle">
                <div class="block-contact-list" data-aos="fade-up" data-aos-duration="600" data-aos-delay="200">
                  <a href="mailto:info@baars-bloembinders.nl">
                    <span class="msg-icon icons"></span>
                    <div class="block-contat-in">
						<?php echo get_post_meta($post->ID, 'Email Address', true);?>
                    </div>
                  </a>
                </div>
                <div class="block-contact-list" data-aos="fade-up" data-aos-duration="600" data-aos-delay="300">
                  <a href="tel:030-6885-355">
                    <span class="phone-icon icons"></span>
                    <div class="block-contat-in">
						<?php echo get_post_meta($post->ID, 'Telefoon', true);?>
                    </div>
                  </a>
                </div>
                <div class="block-contact-list" data-aos="fade-up" data-aos-duration="600" data-aos-delay="400">
                  <a href="javascript:void(0);">
                    <span class="address-icon icons"></span>
                    <div class="block-contat-in">
						<?php echo get_post_meta($post->ID, 'Address', true);?>
                    </div>
                  </a>
                </div>
              </div>
              <div class="col-sm-5 form-block-con" data-aos="fade-up" data-aos-duration="600" data-aos-delay="300">
                <div class="form-contact-fields">
				<?php echo do_shortcode('[contact-form-7 id="96" title="Contact form 1"]');?>
                </div>
              </div>
            </div>
          </div>
        </section>
        
		<section class="map-view">
		<?php dynamic_sidebar('sidebar-9');?>
        </section>
	<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content contact-modal">
    <div class="success-block" style="display:block !important;">
          <div class="block-success-alert">
            <figure>
              <img src="http://infinoax.com/static/wp-bbb/wp-content/themes/Bbb-theme/images/check-icon.png" alt="" />
            </figure>
            <h2>Bericht succesvol verzonden</h2>
            <p>We nemen zo snel mogelijk contact met u op</p>
            <a href="javascript:void(0);" class="btn-white-block close">Oké, snap het!!</a>
          </div>
        </div>
  </div>

</div>	

<?php get_footer(); ?>
