<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

?>
 <!DOCTYPE html>
<html>
   <head>
      <title><?php the_title();?></title>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" />
      <link href="<?php echo get_template_directory_uri();?>/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
      <link href="<?php echo get_template_directory_uri();?>/css/bootstrap-select.min.css" type="text/css" rel="stylesheet" />
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.css">
      <link href="<?php echo get_template_directory_uri();?>/css/style.css" type="text/css" rel="stylesheet" />
      <link href="<?php echo get_template_directory_uri();?>/style.css" type="text/css" rel="stylesheet" />
      <link href="<?php echo get_template_directory_uri();?>/css/aos.css" type="text/css" rel="stylesheet" />
	  <?php
	  if(is_cart() OR is_order_received_page()){
		  ?>
      <link href="<?php echo get_template_directory_uri();?>/css/woocommerce/woocommerce.css" type="text/css" rel="stylesheet" />
   <?php
	  }
	  ?></head>
   <body>
         <?php
	if ( is_front_page() ) {
		?>
		<div class="cs-wrapper banner-bg-wrapper">
        <header class="header-main">
		<?php
	}else{
		?>
		<div class="cs-wrapper">
        <header class="header-main header-inner">
		<?php
	}
		?>
          <div class="container">
		 <?php
	if ( is_front_page() ) {
		?>
            <div class="logo-header">
           <?php echo the_custom_logo();?>
            </div>
			<?php
	}else{
		?>
			       <div class="logo-header">
           <?php dynamic_sidebar('sidebar-11');?>
            </div>
			<?php
	}
	?>
            <div class="navigation-main">
				  <?php wp_nav_menu(array('menu'=>'main-menu','menu_class'=>'nav'));?>
            </div>
            <div class="header-right">
              <div class="cart-btn">
			  <?php global $woocommerce;
			  ?>
                <a href="/static/wp-bbb/cart/"><img src="<?php echo get_template_directory_uri();?>/images/cart-icon-2.png"></a>
				<span class="cartCount"><?php echo $woocommerce->cart->cart_contents_count;?></span>
              </div>
              <div class="search-btn">
                <a href="javascript:void(0);"><img src="<?php echo get_template_directory_uri();?>/images/sarch-icon.png" class="icon-search-black"><span class="cross">&times;</span></a>
                <div class="search-block-ui">
				  <form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
						<input type="text" class="search-field text-field" placeholder="Typ uw zoekopdracht hier" value="<?php echo get_search_query(); ?>" name="s" />
						<input type="submit" value="" class="search-submit"><span class="screen-reader-text" />
					
				</form>
                </div>
              </div>
              <button class="hamburger">
                <span class="hm-1"></span>
                <span class="hm-2"></span>
                <span class="hm-3"></span>
              </button>
            </div>
          </div>
        </header>
       