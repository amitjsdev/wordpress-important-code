<?php
/**
 * Template name: ajax-products
 */


if(isset($_POST)){
	$pricepara=$_POST['pricepara'];
		$orderby=$_POST['orderby'];
		global $product;
		if(isset($_POST['product_cat_arr'])){
		$postOffset=$_POST['post_offset'];
		$posts_per_page = $_POST['posts_per_page'];
		 $product_cat = $_POST['product_cat_arr'];
		
			$args = array(
				'post_type' => 'product',
				'orderby' => 'meta_value_num',
				'meta_key'    =>  $pricepara,
				'order'    =>  $orderby,
				'offset'  => (int)$postOffset,
				'tax_query' => array(
					array(
						'taxonomy'  => 'product_cat',
						'field'     => 'id',
						'terms'     => $_POST['product_cat_arr'],
						'operator'  =>  'IN'
					),
				),
				'posts_per_page' => (int)$posts_per_page
			);
		$result_data= array();
  
		$loop = new WP_Query( $args );
			while ( $loop->have_posts() ) : $loop->the_post();
				$result= array();
			$resr = "1";
				global $product;
			$_product = wc_get_product( $product->get_id());	
			
			$result['get_price'] = $_product->get_price();				
			$result['get_id'] =$product->get_id();
			$image = wp_get_attachment_image_src( get_post_thumbnail_id( $loop->post->ID ), 'single-post-thumbnail' );
			$result['image'] =$image[0];
			$result['get_the_content'] =get_the_content();
			$result['get_the_title'] =get_the_title();
			$result['get_permalink'] =get_permalink( $product->get_id() );
			
			$result_data[] =$result;
		
		endwhile;
		wp_reset_postdata();
		 echo json_encode($result_data,true);

	// Always use die() in the end of ajax functions


	}elseif(isset($_POST['product_noCat'])){
		$postOffset=$_POST['post_offset'];
		$posts_per_page = $_POST['posts_per_page'];
				$args = array(
					'post_type' => 'product',
					 'orderby' => 'meta_value_num',
					'meta_key'    =>  $pricepara,
					'order'    =>  $orderby,
					'offset'  => (int)$postOffset,
					'posts_per_page' => (int)$posts_per_page
				); 
				
				$result_data= array();
				$loop = new WP_Query( $args );
					while ( $loop->have_posts() ) : $loop->the_post();
						$result= array();
					$resr = "1";
						global $product;
					$_product = wc_get_product( $product->get_id());	
					
					$result['get_price'] = $_product->get_price();				
					$result['get_id'] =$product->get_id();
					$image = wp_get_attachment_image_src( get_post_thumbnail_id( $loop->post->ID ), 'single-post-thumbnail' );
					$result['image'] =$image[0];
					$result['get_the_content'] =get_the_content();
					$result['get_the_title'] =get_the_title();
					$result['get_permalink'] =get_permalink( $product->get_id() );
					
					$result_data[] =$result;
				
				endwhile;
				wp_reset_postdata();
				 echo json_encode($result_data,true);
		
	}else{
		
	$postOffset=$_POST['post_offset'];
	/* 	$postOffset=9; */
		$posts_per_page = $_POST['posts_per_page'];
	/* 	$posts_per_page = 9;
		$product_cat = 21; */
		 $product_cat = $_POST['product_cat'];
						$args = array(
							'post_type' => 'product',
							'orderby' => 'meta_value_num',
							'meta_key'    =>  $pricepara,
							'order'    =>  $orderby,				
							'offset'  => (int)$postOffset,
							'tax_query' => array(
								array(
									'taxonomy'  => 'product_cat',
									'field'     => 'id',
									'terms'     => $product_cat,
									'operator'  =>  'IN'
								),
							),
							'posts_per_page' => (int)$posts_per_page
						);
		$result_data= array();

		$loop = new WP_Query( $args );
			while ( $loop->have_posts() ) : $loop->the_post();
				$result= array();
			$resr = "1";
				global $product;
			$_product = wc_get_product( $product->get_id());	
			
			$result['get_price'] = $_product->get_price();				
			$result['get_id'] =$product->get_id();
			$image = wp_get_attachment_image_src( get_post_thumbnail_id( $loop->post->ID ), 'single-post-thumbnail' );
			$result['image'] =$image[0];
			$result['get_the_content'] =get_the_content();
			$result['get_the_title'] =get_the_title();
			$result['get_permalink'] =get_permalink( $product->get_id() );
			
			$result_data[] =$result;
					
		endwhile;
		wp_reset_postdata();
		echo json_encode($result_data,true);
	}
}